<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/access/denied' => [[['_route' => 'access_denied_handler', '_controller' => 'App\\Controller\\AccessDeniedHandlerController::index'], null, null, null, false, false, null]],
        '/activite' => [[['_route' => 'activite_index', '_controller' => 'App\\Controller\\ActiviteController::index'], null, ['GET' => 0], null, true, false, null]],
        '/activite/new' => [[['_route' => 'activite_new', '_controller' => 'App\\Controller\\ActiviteController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/camping' => [[['_route' => 'camping_index', '_controller' => 'App\\Controller\\CampingController::index'], null, ['GET' => 0], null, true, false, null]],
        '/camping/new' => [[['_route' => 'camping_new', '_controller' => 'App\\Controller\\CampingController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/contact' => [[['_route' => 'contact', '_controller' => 'App\\Controller\\ContactController::index'], null, null, null, false, false, null]],
        '/email' => [[['_route' => 'send_email', '_controller' => 'App\\Controller\\ContactController::sendEmail'], null, null, null, false, false, null]],
        '/destination' => [[['_route' => 'destination', '_controller' => 'App\\Controller\\DestinationController::index'], null, null, null, false, false, null]],
        '/destination/filter' => [[['_route' => 'destination_filter', '_controller' => 'App\\Controller\\DestinationController::filterDestination'], null, null, null, false, false, null]],
        '/comentaire' => [[['_route' => 'comentaire', '_controller' => 'App\\Controller\\DestinationDetailsController::comentaire'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/accuiel' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, true, false, null]],
        '/hotel' => [[['_route' => 'hotel_index', '_controller' => 'App\\Controller\\HotelController::index'], null, ['GET' => 0], null, true, false, null]],
        '/hotel/new' => [[['_route' => 'hotel_new', '_controller' => 'App\\Controller\\HotelController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/marker' => [[['_route' => 'marker_index', '_controller' => 'App\\Controller\\MarkerController::index'], null, ['GET' => 0], null, true, false, null]],
        '/marker/new' => [[['_route' => 'marker_new', '_controller' => 'App\\Controller\\MarkerController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/region' => [[['_route' => 'region_index', '_controller' => 'App\\Controller\\RegionController::index'], null, ['GET' => 0], null, true, false, null]],
        '/region/new' => [[['_route' => 'region_new', '_controller' => 'App\\Controller\\RegionController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/register' => [[['_route' => 'app_register', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/resto' => [[['_route' => 'resto_index', '_controller' => 'App\\Controller\\RestoController::index'], null, ['GET' => 0], null, true, false, null]],
        '/resto/new' => [[['_route' => 'resto_new', '_controller' => 'App\\Controller\\RestoController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/ville' => [[['_route' => 'ville_index', '_controller' => 'App\\Controller\\VilleController::index'], null, ['GET' => 0], null, true, false, null]],
        '/ville/new' => [[['_route' => 'ville_new', '_controller' => 'App\\Controller\\VilleController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin' => [[['_route' => 'easyadmin', '_controller' => 'EasyCorp\\Bundle\\EasyAdminBundle\\Controller\\EasyAdminController::indexAction'], null, null, null, true, false, null]],
        '/ controller:App\\Controller\\HomeController::index' => [[['_route' => 'index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/activite/([^/]++)(?'
                    .'|(*:28)'
                    .'|/(?'
                        .'|edit(*:43)'
                        .'|like(*:54)'
                    .')'
                    .'|(*:62)'
                .')'
                .'|/camping/([^/]++)(?'
                    .'|(*:90)'
                    .'|/(?'
                        .'|edit(*:105)'
                        .'|like(*:117)'
                    .')'
                    .'|(*:126)'
                .')'
                .'|/([^/]++)/details(*:152)'
                .'|/hotel/([^/]++)(?'
                    .'|(*:178)'
                    .'|/(?'
                        .'|edit(*:194)'
                        .'|like(*:206)'
                    .')'
                    .'|(*:215)'
                .')'
                .'|/marker/([^/]++)(?'
                    .'|(*:243)'
                    .'|/edit(*:256)'
                    .'|(*:264)'
                .')'
                .'|/re(?'
                    .'|gion/([^/]++)(?'
                        .'|(*:295)'
                        .'|/edit(*:308)'
                        .'|(*:316)'
                    .')'
                    .'|sto/([^/]++)(?'
                        .'|(*:340)'
                        .'|/(?'
                            .'|edit(*:356)'
                            .'|like(*:368)'
                        .')'
                        .'|(*:377)'
                    .')'
                .')'
                .'|/ville/([^/]++)(?'
                    .'|(*:405)'
                    .'|/(?'
                        .'|edit(*:421)'
                        .'|like(*:433)'
                    .')'
                    .'|(*:442)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        28 => [[['_route' => 'activite_show', '_controller' => 'App\\Controller\\ActiviteController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        43 => [[['_route' => 'activite_edit', '_controller' => 'App\\Controller\\ActiviteController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        54 => [[['_route' => 'activite_like', '_controller' => 'App\\Controller\\ActiviteController::like'], ['id'], null, null, false, false, null]],
        62 => [[['_route' => 'activite_delete', '_controller' => 'App\\Controller\\ActiviteController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        90 => [[['_route' => 'camping_show', '_controller' => 'App\\Controller\\CampingController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        105 => [[['_route' => 'camping_edit', '_controller' => 'App\\Controller\\CampingController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        117 => [[['_route' => 'camping_like', '_controller' => 'App\\Controller\\CampingController::like'], ['id'], null, null, false, false, null]],
        126 => [[['_route' => 'camping_delete', '_controller' => 'App\\Controller\\CampingController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        152 => [[['_route' => 'destination_details', '_controller' => 'App\\Controller\\DestinationDetailsController::index'], ['name'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        178 => [[['_route' => 'hotel_show', '_controller' => 'App\\Controller\\HotelController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        194 => [[['_route' => 'hotel_edit', '_controller' => 'App\\Controller\\HotelController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        206 => [[['_route' => 'hotel_like', '_controller' => 'App\\Controller\\HotelController::like'], ['id'], null, null, false, false, null]],
        215 => [[['_route' => 'hotel_delete', '_controller' => 'App\\Controller\\HotelController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        243 => [[['_route' => 'marker_show', '_controller' => 'App\\Controller\\MarkerController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        256 => [[['_route' => 'marker_edit', '_controller' => 'App\\Controller\\MarkerController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        264 => [[['_route' => 'marker_delete', '_controller' => 'App\\Controller\\MarkerController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        295 => [[['_route' => 'region_show', '_controller' => 'App\\Controller\\RegionController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        308 => [[['_route' => 'region_edit', '_controller' => 'App\\Controller\\RegionController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        316 => [[['_route' => 'region_delete', '_controller' => 'App\\Controller\\RegionController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        340 => [[['_route' => 'resto_show', '_controller' => 'App\\Controller\\RestoController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        356 => [[['_route' => 'resto_edit', '_controller' => 'App\\Controller\\RestoController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        368 => [[['_route' => 'resto_like', '_controller' => 'App\\Controller\\RestoController::like'], ['id'], null, null, false, false, null]],
        377 => [[['_route' => 'resto_delete', '_controller' => 'App\\Controller\\RestoController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        405 => [[['_route' => 'ville_show', '_controller' => 'App\\Controller\\VilleController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        421 => [[['_route' => 'ville_edit', '_controller' => 'App\\Controller\\VilleController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        433 => [[['_route' => 'ville_like', '_controller' => 'App\\Controller\\VilleController::like'], ['id'], null, null, false, false, null]],
        442 => [
            [['_route' => 'ville_delete', '_controller' => 'App\\Controller\\VilleController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
