<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* destination/index.html.twig */
class __TwigTemplate_d3570f323219a58b684245a0670f463255fe478440c18c8b9f49c8882ea6e3a4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "destination/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Hello DestinationController!
";
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 7), "set", [0 => "destination", 1 => "destination"], "method", false, false, false, 7), "html", null, true);
        echo "
\t";
        // line 8
        $context["v"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 8), "remove", [0 => "ville"], "method", false, false, false, 8);
        // line 9
        echo "\t";
        $context["c"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 9), "remove", [0 => "contact"], "method", false, false, false, 9);
        // line 10
        echo "
\t<!-- bradcam_area  -->
\t<div class=\"bradcam_area bradcam_bg_2\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-xl-12\">
\t\t\t\t\t<div class=\"bradcam_text text-center\">
\t\t\t\t\t\t<h3>Destinations</h3>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!--/ bradcam_area  -->
\t<script>
\t\tvar nameVilles = [];
\t</script>
\t";
        // line 27
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["villes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["ville"]) {
            // line 28
            echo "\t\t<script>
\t\t\tnameVilles.push(\"";
            // line 29
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 29), "html", null, true);
            echo "\");
\t\t</script>
\t\t<div class=\"js-user-rating\" data-is-authenticated=\"";
            // line 31
            echo json_encode($context["ville"]);
            echo "\">
     </div>
\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ville'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 34
        echo "     
\t<div class=\"popular_places_area\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-lg-4\">
\t\t\t\t\t<div class=\"filter_result_wrap\">
\t\t\t\t\t\t<h3>Filter de résultats</h3>
\t\t\t\t\t\t<form class=\"chatAjaxForm\" action=\"";
        // line 41
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("destination_filter");
        echo "\" method=\"post\">
\t\t\t\t\t\t\t<div class=\"filter_bordered\">
\t\t\t\t\t\t\t\t<div class=\"filter_inner\">
\t\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t\t<select id=\"region\" name=\"idRegion\" class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"0\" selected>toutes les Régions</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 49
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["regions"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["region"]) {
            // line 50
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["region"], "id", [], "any", false, false, false, 50), "html", null, true);
            echo "\">";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["region"], "nom", [], "any", false, false, false, 50), "html", null, true);
            echo "</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['region'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 52
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"form-group\">
\t\t\t\t\t\t\t\t\t\t\t\t<select class=\"form-control\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<option data-display=\"Type voyage\">Type voyage</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"1\">Trip</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"2\">Famille</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"4\">Aventure</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"4\">Séjour</option>
\t\t\t\t\t\t\t\t\t\t\t\t\t<option value=\"4\">Randonnée</option>
\t\t\t\t\t\t\t\t\t\t\t\t</select>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"reset_btn\">
\t\t\t\t\t\t\t\t\t<button class=\"boxed-btn4\" type=\"submit\">Réinitialiser</button>
\t\t\t\t\t\t\t\t\t<p id=\"ana\"></p>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</form>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-lg-8\">
\t\t\t\t\t<div class=\"row\">

\t\t\t\t\t\t";
        // line 82
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["villes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["ville"]) {
            // line 83
            echo "\t\t\t\t\t\t\t<div id=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 83), "html", null, true);
            echo "\" class=\"col-lg-6 col-md-6\">
\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t<img src=\"";
            // line 86
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/place/" . twig_get_attribute($this->env, $this->source, $context["ville"], "image", [], "any", false, false, false, 86))), "html", null, true);
            echo "\" alt=";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 86), "html", null, true);
            echo ">
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 89
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("destination_details", ["name" => twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 89)]), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t<h3>";
            // line 90
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 90), ["_" => " "]), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t";
            // line 93
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 95
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ville_like", ["id" => twig_get_attribute($this->env, $this->source, $context["ville"], "id", [], "any", false, false, false, 95)]), "html", null, true);
            echo "\" class=\"btn btn-link js-like\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 96
            if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 96) && twig_get_attribute($this->env, $this->source, $context["ville"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 96)], "method", false, false, false, 96))) {
                // line 97
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 99
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 101
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks\">";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "likes", [], "any", false, false, false, 101)), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ville'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 111
        echo "\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t";
    }

    // line 118
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 119
        echo "\t\t<script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/filter-ajax.js"), "html", null, true);
        echo "\"></script>
\t";
    }

    public function getTemplateName()
    {
        return "destination/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  254 => 119,  250 => 118,  240 => 111,  223 => 101,  219 => 99,  215 => 97,  213 => 96,  209 => 95,  205 => 93,  200 => 90,  196 => 89,  188 => 86,  181 => 83,  177 => 82,  145 => 52,  134 => 50,  130 => 49,  119 => 41,  110 => 34,  101 => 31,  96 => 29,  93 => 28,  89 => 27,  70 => 10,  67 => 9,  65 => 8,  60 => 7,  56 => 6,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "destination/index.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\destination\\index.html.twig");
    }
}
