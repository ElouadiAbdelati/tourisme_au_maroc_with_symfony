<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @EasyAdmin/data_collector/easyadmin.html.twig */
class __TwigTemplate_b0781d2150c8451e8c971886830735e2799a2b6b1b368766c4c3b56d3958c050 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'toolbar' => [$this, 'block_toolbar'],
            'menu' => [$this, 'block_menu'],
            'panel' => [$this, 'block_panel'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@EasyAdmin/data_collector/easyadmin.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_toolbar($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 4
        echo "    ";
        if (twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "isEasyAdminAction", [], "any", false, false, false, 4)) {
            // line 5
            echo "        ";
            $context["profiler_markup_version"] = (((isset($context["profiler_markup_version"]) || array_key_exists("profiler_markup_version", $context))) ? (_twig_default_filter(($context["profiler_markup_version"] ?? null), 1)) : (1));
            // line 6
            echo "
        ";
            // line 7
            ob_start(function () { return ''; });
            // line 8
            echo "            ";
            $context["icon_fill_color"] = ((0 === twig_compare(($context["profiler_markup_version"] ?? null), 1)) ? ("#222") : ("#AAA"));
            // line 9
            echo "            ";
            $context["icon_height"] = ((0 === twig_compare(($context["profiler_markup_version"] ?? null), 1)) ? ("28") : ("24"));
            // line 10
            echo "            <span class=\"icon\">";
            echo twig_include($this->env, $context, "@EasyAdmin/data_collector/icon.svg.twig", ["fill_color" => ($context["icon_fill_color"] ?? null), "height" => ($context["icon_height"] ?? null)]);
            echo "</span>
            <span class=\"sf-toolbar-value sf-toolbar-status\">";
            // line 11
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "numEntities", [], "any", false, false, false, 11), "html", null, true);
            echo "</span>
        ";
            $context["icon"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 13
            echo "
        ";
            // line 14
            ob_start(function () { return ''; });
            // line 15
            echo "        <div class=\"sf-toolbar-info-piece\">
            <b>EasyAdmin version</b>
            <span class=\"sf-toolbar-status\">";
            // line 17
            echo twig_escape_filter($this->env, twig_constant("EasyCorp\\Bundle\\EasyAdminBundle\\EasyAdminBundle::VERSION"), "html", null, true);
            echo "</span>
        </div>
        <div class=\"sf-toolbar-info-piece\">
            <b>Managed entities</b>
            <span class=\"sf-toolbar-status\">";
            // line 21
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "numEntities", [], "any", false, false, false, 21), "html", null, true);
            echo "</span>
        </div>
        ";
            $context["text"] = ('' === $tmp = ob_get_clean()) ? '' : new Markup($tmp, $this->env->getCharset());
            // line 24
            echo "
        ";
            // line 25
            echo twig_include($this->env, $context, "@WebProfiler/Profiler/toolbar_item.html.twig", ["link" => true]);
            echo "
    ";
        }
    }

    // line 29
    public function block_menu($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 30
        echo "    <span class=\"label ";
        echo (( !twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "isEasyAdminAction", [], "any", false, false, false, 30)) ? ("disabled") : (""));
        echo "\">
        <span class=\"icon\">";
        // line 31
        echo twig_include($this->env, $context, "@EasyAdmin/data_collector/icon.svg.twig", ["height" => 32]);
        echo "</span>
        <strong>EasyAdmin</strong>
    </span>
";
    }

    // line 36
    public function block_panel($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 37
        echo "    ";
        $context["profiler_markup_version"] = (((isset($context["profiler_markup_version"]) || array_key_exists("profiler_markup_version", $context))) ? (_twig_default_filter(($context["profiler_markup_version"] ?? null), 1)) : (1));
        // line 38
        echo "
    <h2>EasyAdmin <small>(";
        // line 39
        echo twig_escape_filter($this->env, twig_constant("EasyCorp\\Bundle\\EasyAdminBundle\\EasyAdminBundle::VERSION"), "html", null, true);
        echo ")</small></h2>

    ";
        // line 41
        if ( !twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "isEasyAdminAction", [], "any", false, false, false, 41)) {
            // line 42
            echo "
        <div class=\"empty\">
            <p>No information available because this route is not related to EasyAdmin.</p>
        </div>

    ";
        } else {
            // line 48
            echo "
        ";
            // line 49
            if (0 === twig_compare(($context["profiler_markup_version"] ?? null), 1)) {
                // line 50
                echo "
            <h3>Request Parameters</h3>
            ";
                // line 52
                echo twig_include($this->env, $context, "@WebProfiler/Profiler/table.html.twig", ["data" => twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 52)]);
                echo "

        ";
            } else {
                // line 55
                echo "
            ";
                // line 56
                if (twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 56)) {
                    // line 57
                    echo "            <div class=\"metrics\">
                <div class=\"metric\">
                    <span class=\"value\">";
                    // line 59
                    echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, true, false, 59), "action", [], "any", true, true, false, 59)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, true, false, 59), "action", [], "any", false, false, false, 59), "-")) : ("-")), "html", null, true);
                    echo "</span>
                    <span class=\"label\">Action</span>
                </div>

                <div class=\"metric\">
                    <span class=\"value\">";
                    // line 64
                    echo twig_escape_filter($this->env, ((twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, true, false, 64), "entity", [], "any", true, true, false, 64)) ? (_twig_default_filter(twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, true, false, 64), "entity", [], "any", false, false, false, 64), "-")) : ("-")), "html", null, true);
                    echo "</span>
                    <span class=\"label\">Entity Name</span>
                </div>

                ";
                    // line 68
                    if (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 68), "id", [], "any", false, false, false, 68)) {
                        // line 69
                        echo "                    <div class=\"metric\">
                        <span class=\"value\">";
                        // line 70
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 70), "id", [], "any", false, false, false, 70), "html", null, true);
                        echo "</span>
                        <span class=\"label\">ID</span>
                    </div>
                ";
                    } elseif (twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source,                     // line 73
($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 73), "sort_field", [], "any", false, false, false, 73)) {
                        // line 74
                        echo "                    <div class=\"metric\">
                        <span class=\"value\">";
                        // line 75
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 75), "sort_field", [], "any", false, false, false, 75), "html", null, true);
                        echo " <span class=\"unit\">(";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "requestParameters", [], "any", false, false, false, 75), "sort_direction", [], "any", false, false, false, 75), "html", null, true);
                        echo ")</span></span>
                        <span class=\"label\">Sorting</span>
                    </div>
                ";
                    }
                    // line 79
                    echo "            </div>
            ";
                }
                // line 81
                echo "
        ";
            }
            // line 83
            echo "
        <div class=\"sf-tabs\">
            <div class=\"tab\">
                <h3 class=\"tab-title\">Current Entity Configuration</h3>
                <div class=\"tab-content\">
                    ";
            // line 88
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "currentEntityConfig", [], "any", false, false, false, 88)], "method", false, false, false, 88);
            echo "
                </div>

                <br>
            </div>

            <div class=\"tab\">
                <h3 class=\"tab-title\">Full Backend Configuration</h3>
                <div class=\"tab-content\">

                    <h4>Basic Configuration</h4>
                    ";
            // line 99
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => ["site_name" => (($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 = twig_get_attribute($this->env, $this->source,             // line 100
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 100)) && is_array($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4) || $__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4 instanceof ArrayAccess ? ($__internal_f607aeef2c31a95a7bf963452dff024ffaeb6aafbe4603f9ca3bec57be8633f4["site_name"] ?? null) : null), "formats" => (($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 = twig_get_attribute($this->env, $this->source,             // line 101
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 101)) && is_array($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144) || $__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144 instanceof ArrayAccess ? ($__internal_62824350bc4502ee19dbc2e99fc6bdd3bd90e7d8dd6e72f42c35efd048542144["formats"] ?? null) : null)]], "method", false, false, false, 99);
            // line 102
            echo "

                    <h4>Design Configuration</h4>
                    ";
            // line 105
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => ["design" => (($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b = twig_get_attribute($this->env, $this->source,             // line 106
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 106)) && is_array($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b) || $__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b instanceof ArrayAccess ? ($__internal_1cfccaec8dd2e8578ccb026fbe7f2e7e29ac2ed5deb976639c5fc99a6ea8583b["design"] ?? null) : null)]], "method", false, false, false, 105);
            // line 107
            echo "

                    <h4>Actions Configuration</h4>
                    ";
            // line 110
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => ["disabled_actions" => (($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 = twig_get_attribute($this->env, $this->source,             // line 111
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 111)) && is_array($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002) || $__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002 instanceof ArrayAccess ? ($__internal_68aa442c1d43d3410ea8f958ba9090f3eaa9a76f8de8fc9be4d6c7389ba28002["disabled_actions"] ?? null) : null), "list" => (($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 = twig_get_attribute($this->env, $this->source,             // line 112
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 112)) && is_array($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4) || $__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4 instanceof ArrayAccess ? ($__internal_d7fc55f1a54b629533d60b43063289db62e68921ee7a5f8de562bd9d4a2b7ad4["list"] ?? null) : null), "edit" => (($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 = twig_get_attribute($this->env, $this->source,             // line 113
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 113)) && is_array($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666) || $__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666 instanceof ArrayAccess ? ($__internal_01476f8db28655ee4ee02ea2d17dd5a92599be76304f08cd8bc0e05aced30666["edit"] ?? null) : null), "new" => (($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e = twig_get_attribute($this->env, $this->source,             // line 114
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 114)) && is_array($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e) || $__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e instanceof ArrayAccess ? ($__internal_01c35b74bd85735098add188b3f8372ba465b232ab8298cb582c60f493d3c22e["new"] ?? null) : null), "show" => (($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 = twig_get_attribute($this->env, $this->source,             // line 115
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 115)) && is_array($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52) || $__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52 instanceof ArrayAccess ? ($__internal_63ad1f9a2bf4db4af64b010785e9665558fdcac0e8db8b5b413ed986c62dbb52["show"] ?? null) : null)]], "method", false, false, false, 110);
            // line 116
            echo "

                    <h4>Entities Configuration</h4>
                    ";
            // line 119
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => ["entities" => (($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 = twig_get_attribute($this->env, $this->source,             // line 120
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 120)) && is_array($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136) || $__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136 instanceof ArrayAccess ? ($__internal_f10a4cc339617934220127f034125576ed229e948660ebac906a15846d52f136["entities"] ?? null) : null)]], "method", false, false, false, 119);
            // line 121
            echo "

                    <h4>Full Backend Configuration</h4>
                    ";
            // line 124
            echo twig_get_attribute($this->env, $this->source, ($context["collector"] ?? null), "dump", [0 => ["easy_admin" => twig_get_attribute($this->env, $this->source,             // line 125
($context["collector"] ?? null), "backendConfig", [], "any", false, false, false, 125)]], "method", false, false, false, 124);
            // line 126
            echo "
                </div>
            </div>
        </div>

    ";
        }
        // line 132
        echo "
    <h3>Additional Resources</h3>

    <ul>
        <li><a href=\"https://github.com/EasyCorp/EasyAdminBundle/issues\">Report an issue</a></li>
        <li><a href=\"https://symfony.com/doc/current/bundles/EasyAdminBundle/index.html\">Read documentation</a></li>
        <li><a href=\"https://github.com/EasyCorp/EasyAdminBundle\">Project homepage</a></li>
    </ul>

";
    }

    public function getTemplateName()
    {
        return "@EasyAdmin/data_collector/easyadmin.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  294 => 132,  286 => 126,  284 => 125,  283 => 124,  278 => 121,  276 => 120,  275 => 119,  270 => 116,  268 => 115,  267 => 114,  266 => 113,  265 => 112,  264 => 111,  263 => 110,  258 => 107,  256 => 106,  255 => 105,  250 => 102,  248 => 101,  247 => 100,  246 => 99,  232 => 88,  225 => 83,  221 => 81,  217 => 79,  208 => 75,  205 => 74,  203 => 73,  197 => 70,  194 => 69,  192 => 68,  185 => 64,  177 => 59,  173 => 57,  171 => 56,  168 => 55,  162 => 52,  158 => 50,  156 => 49,  153 => 48,  145 => 42,  143 => 41,  138 => 39,  135 => 38,  132 => 37,  128 => 36,  120 => 31,  115 => 30,  111 => 29,  104 => 25,  101 => 24,  95 => 21,  88 => 17,  84 => 15,  82 => 14,  79 => 13,  74 => 11,  69 => 10,  66 => 9,  63 => 8,  61 => 7,  58 => 6,  55 => 5,  52 => 4,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "@EasyAdmin/data_collector/easyadmin.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\vendor\\easycorp\\easyadmin-bundle\\src\\Resources\\views\\data_collector\\easyadmin.html.twig");
    }
}
