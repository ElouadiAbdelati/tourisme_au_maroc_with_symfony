<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* @VichUploader/Collector/icon.html.twig */
class __TwigTemplate_4e11bc6d783cd17d7e6ce4d7fbe4cf3e48be9b71400d90cc61cdfe95e18df439 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 2
        echo "<img alt=\"\" src=\"data:image/svg+xml;base64,PHN2ZyB4bWxuczpkYz0iaHR0cDovL3B1cmwub3JnL2RjL2VsZW1lbnRzLzEuMS8iIHhtbG5zOmNj
PSJodHRwOi8vY3JlYXRpdmVjb21tb25zLm9yZy9ucyMiIHhtbG5zOnJkZj0iaHR0cDovL3d3dy53
My5vcmcvMTk5OS8wMi8yMi1yZGYtc3ludGF4LW5zIyIgeG1sbnM6c3ZnPSJodHRwOi8vd3d3Lncz
Lm9yZy8yMDAwL3N2ZyIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczpz
b2RpcG9kaT0iaHR0cDovL3NvZGlwb2RpLnNvdXJjZWZvcmdlLm5ldC9EVEQvc29kaXBvZGktMC5k
dGQiIHhtbG5zOmlua3NjYXBlPSJodHRwOi8vd3d3Lmlua3NjYXBlLm9yZy9uYW1lc3BhY2VzL2lu
a3NjYXBlIiB2ZXJzaW9uPSIxLjEiIGlua3NjYXBlOnZlcnNpb249IjAuNDguMy4xIHI5ODg2IiB3
aWR0aD0iMTk1MCIgaGVpZ2h0PSIxOTUwIiBzb2RpcG9kaTpkb2NuYW1lPSJjbG91ZF91cGxvYWRf
Zm9udF9hd2Vzb21lLnN2ZyIgc3R5bGU9IiI+PHJlY3QgaWQ9ImJhY2tncm91bmRyZWN0IiB3aWR0
aD0iMTAwJSIgaGVpZ2h0PSIxMDAlIiB4PSIwIiB5PSIwIiBmaWxsPSJub25lIiBzdHJva2U9Im5v
bmUiLz4KICA8bWV0YWRhdGEgaWQ9Im1ldGFkYXRhMzAxMSI+CiAgICA8cmRmOlJERj4KICAgICAg
PGNjOldvcmsgcmRmOmFib3V0PSIiPgogICAgICAgIDxkYzpmb3JtYXQ+aW1hZ2Uvc3ZnK3htbDwv
ZGM6Zm9ybWF0PgogICAgICAgIDxkYzp0eXBlIHJkZjpyZXNvdXJjZT0iaHR0cDovL3B1cmwub3Jn
L2RjL2RjbWl0eXBlL1N0aWxsSW1hZ2UiLz4KICAgICAgPC9jYzpXb3JrPgogICAgPC9yZGY6UkRG
PgogIDwvbWV0YWRhdGE+CiAgPGRlZnMgaWQ9ImRlZnMzMDA5Ii8+CiAgPHNvZGlwb2RpOm5hbWVk
dmlldyBwYWdlY29sb3I9IiNmZmZmZmYiIGJvcmRlcmNvbG9yPSIjNjY2NjY2IiBib3JkZXJvcGFj
aXR5PSIxIiBvYmplY3R0b2xlcmFuY2U9IjEwIiBncmlkdG9sZXJhbmNlPSIxMCIgZ3VpZGV0b2xl
cmFuY2U9IjEwIiBpbmtzY2FwZTpwYWdlb3BhY2l0eT0iMCIgaW5rc2NhcGU6cGFnZXNoYWRvdz0i
MiIgaW5rc2NhcGU6d2luZG93LXdpZHRoPSI2NDAiIGlua3NjYXBlOndpbmRvdy1oZWlnaHQ9IjQ4
MCIgaWQ9Im5hbWVkdmlldzMwMDciIHNob3dncmlkPSJmYWxzZSIgaW5rc2NhcGU6em9vbT0iMC4x
MzE2OTY0MyIgaW5rc2NhcGU6Y3g9Ijk2MCIgaW5rc2NhcGU6Y3k9Ijg5NiIgaW5rc2NhcGU6d2lu
ZG93LXg9IjAiIGlua3NjYXBlOndpbmRvdy15PSIyNSIgaW5rc2NhcGU6d2luZG93LW1heGltaXpl
ZD0iMCIgaW5rc2NhcGU6Y3VycmVudC1sYXllcj0ic3ZnMzAwMSIvPgogIAo8ZyBjbGFzcz0iY3Vy
cmVudExheWVyIiBzdHlsZT0iIj48dGl0bGU+TGF5ZXIgMTwvdGl0bGU+PGcgaWQ9ImczMDAzIiBj
bGFzcz0ic2VsZWN0ZWQiIGZpbGw9IiNmZmZmZmYiIGZpbGwtb3BhY2l0eT0iMSI+CiAgICA8cGF0
aCBkPSJtMTMwMi43Nzk2NjExNzg1ODg5LDc1Ni4yMzczMDQ2ODc1IHEwLC0xNCAtOSwtMjMgbC0z
NTIsLTM1MiBxLTksLTkgLTIzLC05IHEtMTQsMCAtMjMsOSBMNTQ0Ljc3OTY2MTE3ODU4ODksNzMy
LjIzNzMwNDY4NzUgcS0xMCwxMiAtMTAsMjQgcTAsMTQgOSwyMyBxOSw5IDIzLDkgSDc5MC43Nzk2
NjExNzg1ODg5IFYxMTQwLjIzNzMwNDY4NzUgcTAsMTMgOS41LDIyLjUgUTgwOS43Nzk2NjExNzg1
ODg5LDExNzIuMjM3MzA0Njg3NSA4MjIuNzc5NjYxMTc4NTg4OSwxMTcyLjIzNzMwNDY4NzUgaDE5
MiBxMTMsMCAyMi41LC05LjUgcTkuNSwtOS41IDkuNSwtMjIuNSB2LTM1MiBoMjI0IHExMywwIDIy
LjUsLTkuNSBxOS41LC05LjUgOS41LC0yMi41IHpNMTk0Mi43Nzk2NjExNzg1ODg5LDEwNDQuMjM3
MzA0Njg3NSBRMTk0Mi43Nzk2NjExNzg1ODg5LDEyMDMuMjM3MzA0Njg3NSAxODMwLjI3OTY2MTE3
ODU4ODksMTMxNS43MzczMDQ2ODc1IFExNzE3Ljc3OTY2MTE3ODU4ODksMTQyOC4yMzczMDQ2ODc1
IDE1NTguNzc5NjYxMTc4NTg4OSwxNDI4LjIzNzMwNDY4NzUgSDQ3MC43Nzk2NjExNzg1ODg4NyBR
Mjg1Ljc3OTY2MTE3ODU4ODg3LDE0MjguMjM3MzA0Njg3NSAxNTQuMjc5NjYxMTc4NTg4ODcsMTI5
Ni43MzczMDQ2ODc1IFEyMi43Nzk2NjExNzg1ODg4NjcsMTE2NS4yMzczMDQ2ODc1IDIyLjc3OTY2
MTE3ODU4ODg2Nyw5ODAuMjM3MzA0Njg3NSBxMCwtMTMwIDcwLC0yNDAgcTcwLC0xMTAgMTg4LC0x
NjUgcS0yLC0zMCAtMiwtNDMgcTAsLTIxMiAxNTAsLTM2MiBxMTUwLC0xNTAgMzYyLC0xNTAgcTE1
NiwwIDI4NS41LDg3IHExMjkuNSw4NyAxODguNSwyMzEgcTcxLC02MiAxNjYsLTYyIHExMDYsMCAx
ODEsNzUgcTc1LDc1IDc1LDE4MSBxMCw3NiAtNDEsMTM4IHExMzAsMzEgMjEzLjUsMTM1LjUgUTE5
NDIuNzc5NjYxMTc4NTg4OSw5MTAuMjM3MzA0Njg3NSAxOTQyLjc3OTY2MTE3ODU4ODksMTA0NC4y
MzczMDQ2ODc1IHoiIGlkPSJwYXRoMzAwNSIgaW5rc2NhcGU6Y29ubmVjdG9yLWN1cnZhdHVyZT0i
MCIgc3R5bGU9IiIgc3Ryb2tlLXdpZHRoPSIwIiBmaWxsPSIjZmZmZmZmIiBmaWxsLW9wYWNpdHk9
IjEiLz4KICA8L2c+PC9nPjwvc3ZnPg==\" width=24\" height=24\">";
    }

    public function getTemplateName()
    {
        return "@VichUploader/Collector/icon.html.twig";
    }

    public function getDebugInfo()
    {
        return array (  37 => 2,);
    }

    public function getSourceContext()
    {
        return new Source("", "@VichUploader/Collector/icon.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\vendor\\vich\\uploader-bundle\\templates\\Collector\\icon.html.twig");
    }
}
