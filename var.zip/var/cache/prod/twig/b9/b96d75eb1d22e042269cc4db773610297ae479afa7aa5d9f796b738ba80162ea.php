<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/index.html.twig */
class __TwigTemplate_f1845c85aef56952de0ba8d6de99c9356efcfb687a77e459a2d3e5141f5179f3 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "home/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Hello HomeController!
";
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "
\t<!-- slider_area_start -->
\t<div class=\"slider_area\">
\t\t<div class=\"slider_active owl-carousel\">
\t\t\t<div class=\"single_slider  d-flex align-items-center slider_bg_1 overlay\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t<div class=\"col-xl-12 col-md-12\">
\t\t\t\t\t\t\t<div class=\"slider_text text-center\">
\t\t\t\t\t\t\t\t<h3>Essaouria</h3>
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\tAllez maintenant</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"single_slider  d-flex align-items-center slider_bg_2 overlay\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t<div class=\"col-xl-12 col-md-12\">
\t\t\t\t\t\t\t<div class=\"slider_text text-center\">
\t\t\t\t\t\t\t\t<h3>Tafraout</h3>
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\tAllez maintenant</p>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"single_slider  d-flex align-items-center slider_bg_3 overlay\">
\t\t\t\t<div class=\"container\">
\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t<div class=\"col-xl-12 col-md-12\">
\t\t\t\t\t\t\t<div class=\"slider_text text-center\">
\t\t\t\t\t\t\t\t<h3>Fes</h3>
\t\t\t\t\t\t\t\t<p>
\t\t\t\t\t\t\t\t\tAllez maintenant</p>

\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>

\t</div>
\t<!-- slider_area_end -->


\t<div class=\"popular_places_area\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t<h3>Lieux populaires</h3>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"row\">
\t\t\t\t";
        // line 67
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["villes"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["ville"]) {
            // line 68
            echo "\t\t\t\t\t<div class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t<img src=\"";
            // line 71
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/place/" . twig_get_attribute($this->env, $this->source, $context["ville"], "image", [], "any", false, false, false, 71))), "html", null, true);
            echo "\" alt=\"";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 71), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t<a href=\"";
            // line 74
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("destination_details", ["name" => twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 74)]), "html", null, true);
            echo "\">
\t\t\t\t\t\t\t\t\t<h3>";
            // line 75
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "name", [], "any", false, false, false, 75), "html", null, true);
            echo "</h3>
\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\"   >
\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 79
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ville_like", ["id" => twig_get_attribute($this->env, $this->source, $context["ville"], "id", [], "any", false, false, false, 79)]), "html", null, true);
            echo "\" class=\"btn btn-link js-like\">
\t\t\t\t\t\t\t\t\t\t\t";
            // line 80
            if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 80) && twig_get_attribute($this->env, $this->source, $context["ville"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 80)], "method", false, false, false, 80))) {
                // line 81
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t";
            } else {
                // line 83
                echo "\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 85
            echo "\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks\">";
            echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["ville"], "likes", [], "any", false, false, false, 85)), "html", null, true);
            echo "</span>
\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t</span>

\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['ville'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 95
        echo "\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"row\">
\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t<div class=\"more_place_btn text-center\">
\t\t\t\t\t\t<a class=\"boxed-btn4\" href=\"";
        // line 100
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("destination");
        echo "\">Plus de lieux</a>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>


\t<div class=\"travel_variation_area\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t<h3>
\t\t\t\t\t\t\tNos services</h3>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<div class=\"row\">

\t\t\t\t<div class=\"col-lg-4 col-md-6\">
\t\t\t\t\t<div class=\"single_travel text-center\">
\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t<i class=\"fas fa-swimmer  fa-4x\" style=\"color:red\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<h3>Activités</h3>
\t\t\t\t\t\t<p>Découvrez les activités existantes</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-lg-4 col-md-6\">
\t\t\t\t\t<div class=\"single_travel text-center\">
\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t<i class=\"fas fa-hotel fa-4x\" style=\"color:red\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<h3>Hôtels</h3>
\t\t\t\t\t\t<p>Trouvez votre hôtel au Maroc .</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-lg-4 col-md-6\">
\t\t\t\t\t<div class=\"single_travel text-center\">
\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t<i class=\"fas fa-concierge-bell fa-4x\" style=\"color:red\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<h3>Restaurants</h3>
\t\t\t\t\t\t<p>Trouvez votre restaurant au Maroc.</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t\t<div class=\"col-lg-4 col-md-6\">
\t\t\t\t\t<div class=\"single_travel text-center\">
\t\t\t\t\t\t<div class=\"icon\">
\t\t\t\t\t\t\t<i class=\"fas fa-campground fa-4x\" style=\"color:red\"></i>
\t\t\t\t\t\t</div>
\t\t\t\t\t\t<h3>Campings</h3>
\t\t\t\t\t\t<p>Trouvez un camping au Maroc .</p>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>


";
    }

    public function getTemplateName()
    {
        return "home/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  187 => 100,  180 => 95,  163 => 85,  159 => 83,  155 => 81,  153 => 80,  149 => 79,  142 => 75,  138 => 74,  130 => 71,  125 => 68,  121 => 67,  59 => 7,  55 => 6,  47 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "home/index.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\home\\index.html.twig");
    }
}
