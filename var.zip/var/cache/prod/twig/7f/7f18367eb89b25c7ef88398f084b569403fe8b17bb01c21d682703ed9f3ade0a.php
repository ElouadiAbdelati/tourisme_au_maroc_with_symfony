<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* tests/bootstrap.php */
class __TwigTemplate_8f709d575315305f8cdfe6c89bf023023b247a9819ca9eee36aaa77aa20b5329 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 1
        echo "<?php

use Symfony\\Component\\Dotenv\\Dotenv;

require dirname(__DIR__) . '/vendor/autoload.php';

// if (file_exists(dirname(__DIR__).'/config/bootstrap.php')) {
//     require dirname(__DIR__).'/config/bootstrap.php';
// } elseif (method_exists(Dotenv::class, 'bootEnv')) {
//     (new Dotenv())->bootEnv(dirname(__DIR__).'/.env');
//}
";
    }

    public function getTemplateName()
    {
        return "tests/bootstrap.php";
    }

    public function getDebugInfo()
    {
        return array (  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "tests/bootstrap.php", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\tests\\bootstrap.php");
    }
}
