<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* destination_details/index.html.twig */
class __TwigTemplate_79645506de7b57eabbc37a524dd8433682de024f7ea6b4b955831725afc8a0b7 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $this->parent = $this->loadTemplate("base.html.twig", "destination_details/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        echo "Hello DestinationDetailsController!
";
    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 7
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 7), "set", [0 => "ville", 1 => twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "name", [], "any", false, false, false, 7)], "method", false, false, false, 7), "html", null, true);
        echo "
\t";
        // line 8
        $context["d"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 8), "remove", [0 => "destination"], "method", false, false, false, 8);
        // line 9
        echo "\t";
        $context["c"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "session", [], "any", false, false, false, 9), "remove", [0 => "contact"], "method", false, false, false, 9);
        // line 10
        echo "\t<div class=\"destination_banner_wrap overlay\" style=\"background-image:url(";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/place/" . twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "image", [], "any", false, false, false, 10))), "html", null, true);
        echo ");\">
\t\t<div class=\"destination_text text-center\">
\t\t\t<h3>";
        // line 12
        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "name", [], "any", false, false, false, 12), ["_" => " "]), "html", null, true);
        echo "</h3>
\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t<a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ville_like", ["id" => twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "id", [], "any", false, false, false, 14)]), "html", null, true);
        echo "\" class=\"btn btn-link js-like\">
\t\t\t\t\t";
        // line 15
        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 15) && twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 15)], "method", false, false, false, 15))) {
            // line 16
            echo "\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x \" style=\" color: red;\"></i>
\t\t\t\t\t";
        } else {
            // line 18
            echo "\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\" style=\" color: red;\"></i>
\t\t\t\t\t";
        }
        // line 20
        echo "
\t\t\t\t</a>
\t\t\t</span>
\t\t</div>
\t</div>
\t<!-- start description-->
\t<div class=\"destination_details_info\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t<div class=\"col-lg-8 col-md-9\">
\t\t\t\t\t<div class=\"destination_info\">

\t\t\t\t\t\t<h3>Description</h3>
\t\t\t\t\t\t";
        // line 33
        echo twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "description", [], "any", false, false, false, 33);
        echo "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"bordered_1px\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- end description-->

\t<div class=\"row justify-content-center\">
\t\t<div class=\"col-lg-6\">
\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t<h3>La carte</h3>
\t\t\t</div>
\t\t</div>
\t</div>


\t<!-- start map-->
\t<div class=\"container\">
\t\t<div class=\"d-none d-sm-block mb-5 pb-4\">
\t\t\t<div id=\"map\" style=\"height: 480px; width: 770px; position: relative;\"></div>


\t\t\t<div class=\"col-lg-4\" style=\" left: 790px; top: -480px;\">
\t\t\t\t<div class=\"filter_result_wrap\">
\t\t\t\t\t<h3>Filter de résultats</h3>
\t\t\t\t\t<div class=\"filter_bordered\">
\t\t\t\t\t\t<div class=\"filter_inner\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<form class=\"was-validated\">
\t\t\t\t\t\t\t\t\t";
        // line 64
        if ( !twig_test_empty(($context["hotelMarkers"] ?? null))) {
            // line 65
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 68
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 72
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 75
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 79
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 80
        if ( !twig_test_empty(($context["restoMarkers"] ?? null))) {
            // line 81
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 84
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 88
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 91
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 95
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 96
        if ( !twig_test_empty(($context["activiteMarkers"] ?? null))) {
            // line 97
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 100
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 104
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 107
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 111
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 112
        if ( !twig_test_empty(($context["campingMarkers"] ?? null))) {
            // line 113
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 116
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 120
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 123
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 127
        echo "\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
        // line 137
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<script language=\"JavaScript\" type=\"text/javascript\" src=\"/js/vendor/jquery-1.12.4.min.js\"></script>


\t\t\t<script>
\t\t\t\tvar hotelMarkers = [];
var campingMarkers = [];
var restoMarkers = [];
var activiteMarkers = [];
\t\t\t</script>
\t\t\t";
        // line 151
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["hotelMarkers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["hotelMarker"]) {
            // line 152
            echo "\t\t\t\t<script>
\t\t\t\t\tvar hotelMarker = {
position: {
lat: ";
            // line 155
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "lat", [], "any", false, false, false, 155), "html", null, true);
            echo ",
lng: ";
            // line 156
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "lng", [], "any", false, false, false, 156), "html", null, true);
            echo "
},
title: \"";
            // line 158
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "name", [], "any", false, false, false, 158), [" " => "_"]), "html", null, true);
            echo "\"
};
hotelMarkers.push(hotelMarker);
\t\t\t\t</script>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotelMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 163
        echo "
\t\t\t\t";
        // line 164
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["campingMarkers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["campingMarker"]) {
            // line 165
            echo "\t\t\t\t\t<script>
\t\t\t\t\t\tvar campingMarker = {
position: {
lat: ";
            // line 168
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["campingMarker"], "lat", [], "any", false, false, false, 168), "html", null, true);
            echo ",
lng: ";
            // line 169
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["campingMarker"], "lng", [], "any", false, false, false, 169), "html", null, true);
            echo "
},
title: \"";
            // line 171
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["campingMarker"], "name", [], "any", false, false, false, 171), [" " => "_"]), "html", null, true);
            echo "\"
};
campingMarkers.push(campingMarker);
\t\t\t\t\t</script>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['campingMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 176
        echo "
\t\t\t\t\t";
        // line 177
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["activiteMarkers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteMarker"]) {
            // line 178
            echo "\t\t\t\t\t\t<script>
\t\t\t\t\t\t\tvar activiteMarker = {
position: {
lat: ";
            // line 181
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "lat", [], "any", false, false, false, 181), "html", null, true);
            echo ",
lng: ";
            // line 182
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "lng", [], "any", false, false, false, 182), "html", null, true);
            echo "
},
title: \"";
            // line 184
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "name", [], "any", false, false, false, 184), [" " => "_"]), "html", null, true);
            echo "\"
};
activiteMarkers.push(activiteMarker);
\t\t\t\t\t\t</script>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 189
        echo "
\t\t\t\t\t\t";
        // line 190
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["restoMarkers"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["restoMarker"]) {
            // line 191
            echo "\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tvar restoMarker = {
position: {
lat: ";
            // line 194
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["restoMarker"], "lat", [], "any", false, false, false, 194), "html", null, true);
            echo ",
lng: ";
            // line 195
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["restoMarker"], "lng", [], "any", false, false, false, 195), "html", null, true);
            echo "
},
title: \"";
            // line 197
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["restoMarker"], "name", [], "any", false, false, false, 197), [" " => "_"]), "html", null, true);
            echo "\"
};
restoMarkers.push(restoMarker);
\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['restoMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 202
        echo "
\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tfunction initMap() {
var uluru = {
lat: ";
        // line 206
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["villeMarker"] ?? null), "lat", [], "any", false, false, false, 206), "html", null, true);
        echo ",
lng: ";
        // line 207
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["villeMarker"] ?? null), "lng", [], "any", false, false, false, 207), "html", null, true);
        echo "
};

var map = new google.maps.Map(document.getElementById('map'), {
zoom: 13,
center: uluru,
scrollwheel: true, /*mapTypeId: 'satellite'*/
mapTypeId: google.maps.MapTypeId.ROADMAP
});
var marker = new google.maps.Marker({
position: uluru, map: map, clickable: true, animation: google.maps.Animation.BOUNCE /*DROP*/
});
marker.setTitle(\"cmnt\");
marker.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + marker.getTitle()).offset().top
}, 'slow');
});

var markers = [];

for (let i = 0; i < hotelMarkers.length; i++) {
var mh = new google.maps.Marker({
position: hotelMarkers[i].position, map: map,
// label: \"H\",
icon: {
url: '";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_50.png"), "html", null, true);
        echo "'
}
});
mh.setTitle(hotelMarkers[i].title);

markers.push(mh);
}

for (let i = 0; i < restoMarkers.length; i++) {
var mr = new google.maps.Marker({
position: restoMarkers[i].position, map: map,
// label: \"R\"
icon: '";
        // line 245
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_50.png"), "html", null, true);
        echo "'
});
mr.setTitle(restoMarkers[i].title);

markers.push(mr);
}

for (let i = 0; i < campingMarkers.length; i++) {
var mc = new google.maps.Marker({position: campingMarkers[i].position, map: map, icon: '";
        // line 253
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent50.png"), "html", null, true);
        echo "'});
mc.setTitle(campingMarkers[i].title);

markers.push(mc);
}

for (let i = 0; i < activiteMarkers.length; i++) {
var ma = new google.maps.Marker({position: activiteMarkers[i].position, map: map, icon: '";
        // line 260
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite50.png"), "html", null, true);
        echo "'});
ma.setTitle(activiteMarkers[i].title);

markers.push(ma);
}

var infowindow = new google.maps.InfoWindow();
markers.map((m) => {
m.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + m.getTitle()).offset().top
}, 'slow');
\$(\"#\" + m.getTitle()).hide(1100);
\$(\"#\" + m.getTitle()).show(2000);
// \$(\"#\" + m.getTitle()).animate({height: '+=20%'});


});

m.addListener('mouseover', function () {
infowindow.setContent(m.getTitle());
infowindow.open(map, m);
});
});

\$(\"#customControlValidation1\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation3\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation2\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation4\").change(function () {
if (this.checked) {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

}
\t\t\t\t\t\t\t</script>

\t\t\t\t\t\t\t<script async defer src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyCmC9pqdr3_Wbb9jGSl9EBKNNNAhcA6puE&callback=initMap\"></script>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<!-- end description-->

\t\t\t\t\t<!-- Start meteo -->
\t\t\t\t\t<style type=\"text/css\">
\t\t\t\t\t\t@import url(https://fonts.googleapis.com/css?family=Roboto:400,300);
\t\t\t\t\t\t{
\t\t\t\t\t\t\t# html,
\t\t\t\t\t\t\tbody {
\t\t\t\t\t\t\t\tbackground-color: #F3F3F3;
\t\t\t\t\t\t\t\tfont-family: 'Roboto', sans-serif;
\t\t\t\t\t\t\t} #
\t\t\t\t\t\t}

\t\t\t\t\t\t.card {
\t\t\t\t\t\t\tmargin: 5% auto 0;
\t\t\t\t\t\t\tpadding: 5px 30px;
\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\tborder-radius: 3px;
\t\t\t\t\t\t\tbackground-color: #fff;
\t\t\t\t\t\t\tbox-shadow: 1px 2px 10px rgba(0, 0, 0, 0.2);
\t\t\t\t\t\t\t-webkit-animation: open 2s cubic-bezier(0.39, 0, 0.38, 1);
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes open {
\t\t\t\t\t\t\tfrom {
\t\t\t\t\t\t\t\tpadding: 0 30px;
\t\t\t\t\t\t\t\theight: 0;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\tto {
\t\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}

\t\t\t\t\t\th1,
\t\t\t\t\t\th2,
\t\t\t\t\t\th3,
\t\t\t\t\t\th4 {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t}

\t\t\t\t\t\t.dot {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sky {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\tmargin-top: 108px;
\t\t\t\t\t\t\twidth: 100px;
\t\t\t\t\t\t\theight: 100px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #03A9F4;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sun {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: -3px;
\t\t\t\t\t\t\twidth: 55px;
\t\t\t\t\t\t\theight: 55px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #FFEB3B;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.5s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: 60px;
\t\t\t\t\t\t\tleft: 30px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before,
\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\tdisplay: block;
\t\t\t\t\t\t\tcontent: \"\";
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before {
\t\t\t\t\t\t\tmargin-left: -10px;
\t\t\t\t\t\t\twidth: 51px;
\t\t\t\t\t\t\theight: 18px;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: -10px;
\t\t\t\t\t\t\tleft: -22px;
\t\t\t\t\t\t\twidth: 28px;
\t\t\t\t\t\t\theight: 28px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t\tbox-shadow: 50px -6px 0 6px #fff, 25px -19px 0 10px #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\ttable {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: 10px;
\t\t\t\t\t\t\twidth: 100%;
\t\t\t\t\t\t\ttext-align: center;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(1) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 32px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tcolor: #999;
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes up {
\t\t\t\t\t\t\t0% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t50% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t99% {
\t\t\t\t\t\t\t\t-webkit-animation-play-state: paused;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t100% {
\t\t\t\t\t\t\t\topacity: 1;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t</style>
\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t<h3>La Meteo</h3>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-5\">
\t\t\t\t\t\t\t\t\t<div class=\"card\">

\t\t\t\t\t\t\t\t\t\t<h2 style=\"font-weight: 300; font-size: 2.25em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1); \">";
        // line 545
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "name", [], "any", false, false, false, 545), "html", null, true);
        echo "</h2>
\t\t\t\t\t\t\t\t\t\t<h3 id=\"day0\" style=\"float: right; left: 260px; top: -47px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\"></h3>
\t\t\t\t\t\t\t\t\t\t<h3 style=\"float: left; margin-right: 33px; top: 0px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\" id=\"desc\"></h3>
\t\t\t\t\t\t\t\t\t\t<h1 id=\"temp\" style=\"float: right; color: #666; font-weight: 300; top: 32px; font-size: 6.59375em; line-height: 0.2em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;\">&deg;</h1>
\t\t\t\t\t\t\t\t\t\t<div id=\"sky\"></div>
\t\t\t\t\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<script>
\t\t\t\t\t\tvar lat = ";
        // line 586
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["villeMarker"] ?? null), "lat", [], "any", false, false, false, 586), "html", null, true);
        echo ";
var lng = ";
        // line 587
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["villeMarker"] ?? null), "lng", [], "any", false, false, false, 587), "html", null, true);
        echo ";

fetch('https://api.openweathermap.org/data/2.5/onecall?lat=' + lat + '&lon=' + lng + '&units=metric&appid=7215d0713dbd93f757a51b198da702cc').then(response => response.json()).then(data => {
console.log(data);
document.getElementById(\"temp\").innerHTML = data.current.temp + '&deg;';
document.getElementById(\"sky\").innerHTML = '<img src=' + '";
        // line 592
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/weather/"), "html", null, true);
        echo "' + data.daily[0].weather[0].icon + '.png' + '>';

document.getElementById(\"desc\").innerHTML = data.current.weather[0].description + '<span  id=\"wind\" style=\"margin-left: 24px; color: #999; font-weight: 300;\">Vent ' + data.current.wind_speed + 'm/s <span style=\"margin-left: 0;\" class=\"dot\">•</span> humidité ' + data.current.humidity + '%</span>';

var date0 = new Date();
let dateLocale0 = date0.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});

document.getElementById(\"day0\").innerHTML = dateLocale0;

for (var i = 1; i < 6; i++) {
document.getElementById(\"tempMaxd\" + i).innerHTML = data.daily[i].temp.max + '&deg;';

document.getElementById(\"icond\" + i).innerHTML = '<img style=\"width: 65px\" src=' +'";
        // line 609
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/weather/"), "html", null, true);
        echo "' + data.daily[i].weather[0].icon + '.png' + '>';

document.getElementById(\"tempMind\" + i).innerHTML = data.daily[i].temp.min + '&deg;';


var date = new Date();
date.setDate(new Date().getDate() + i);
let dateLocale = date.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});
document.getElementById(\"day\" + i).innerHTML = dateLocale.substr(0, 3).toUpperCase();

}

});
\t\t\t\t\t</script>

\t\t\t\t\t<!-- End meteo -->


\t\t\t\t\t";
        // line 632
        if (( !twig_test_empty(($context["hotels"] ?? null)) &&  !twig_test_empty(($context["hotelMarkers"] ?? null)))) {
            // line 633
            echo "\t\t\t\t\t\t<!-- start hotels-->
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Hotels</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 644
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["hotelMarkers"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 645
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["hotels"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["hotel"]) {
                    // line 646
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 646), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["hotel"], "nom", [], "any", false, false, false, 646), [" " => "_"]))) {
                        // line 647
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 647), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                        // line 650
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/hotel/" . twig_get_attribute($this->env, $this->source, $context["hotel"], "imgPath", [], "any", false, false, false, 650))), "html", null, true);
                        echo "\" alt=";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotel"], "nom", [], "any", false, false, false, 650), "html", null, true);
                        echo ">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 654
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 654), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 658
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("hotel_like", ["id" => twig_get_attribute($this->env, $this->source, $context["hotel"], "id", [], "any", false, false, false, 658)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-hotel\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 659
                        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 659) && twig_get_attribute($this->env, $this->source, $context["hotel"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 659)], "method", false, false, false, 659))) {
                            // line 660
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 662
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 664
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-hotel\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotel"], "likes", [], "any", false, false, false, 664)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 673
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotel'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 674
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 675
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 679
        echo "\t\t\t\t\t<!-- end hotels-->

\t\t\t\t\t<!-- start Restaurants-->
\t\t\t\t\t";
        // line 682
        if ( !twig_test_empty(($context["restos"] ?? null))) {
            // line 683
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Restaurants</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 693
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["restoMarkers"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 694
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["restos"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["resto"]) {
                    // line 695
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 695), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["resto"], "nom", [], "any", false, false, false, 695), [" " => "_"]))) {
                        // line 696
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 696), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 699
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/resto/" . twig_get_attribute($this->env, $this->source, $context["resto"], "imgPath", [], "any", false, false, false, 699))), "html", null, true);
                        echo "\" alt=\"resto.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 703
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 703), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 707
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("resto_like", ["id" => twig_get_attribute($this->env, $this->source, $context["resto"], "id", [], "any", false, false, false, 707)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-resto\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 708
                        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 708) && twig_get_attribute($this->env, $this->source, $context["resto"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 708)], "method", false, false, false, 708))) {
                            // line 709
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 711
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 713
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-resto\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["resto"], "likes", [], "any", false, false, false, 713)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 722
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resto'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 723
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 724
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 728
        echo "\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start activite-->
\t\t\t\t\t";
        // line 731
        if ( !twig_test_empty(($context["activites"] ?? null))) {
            // line 732
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Activités</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 742
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["activiteMarkers"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 743
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["activites"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["activite"]) {
                    // line 744
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 744), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["activite"], "nom", [], "any", false, false, false, 744), [" " => "_"]))) {
                        // line 745
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 745), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 748
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/activite/" . twig_get_attribute($this->env, $this->source, $context["activite"], "imgPath", [], "any", false, false, false, 748))), "html", null, true);
                        echo "\" alt=\"activite.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 752
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 752), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 756
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activite_like", ["id" => twig_get_attribute($this->env, $this->source, $context["activite"], "id", [], "any", false, false, false, 756)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-activite\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 757
                        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 757) && twig_get_attribute($this->env, $this->source, $context["activite"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 757)], "method", false, false, false, 757))) {
                            // line 758
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 760
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 762
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-activite\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activite"], "likes", [], "any", false, false, false, 762)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 770
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activite'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 771
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 772
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t";
        }
        // line 777
        echo "\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start campings-->
\t\t\t\t\t";
        // line 780
        if ( !twig_test_empty(($context["campings"] ?? null))) {
            // line 781
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Campings</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 791
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable(($context["campingMarkers"] ?? null));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 792
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable(($context["campings"] ?? null));
                foreach ($context['_seq'] as $context["_key"] => $context["camping"]) {
                    // line 793
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 793), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["camping"], "nom", [], "any", false, false, false, 793), [" " => "_"]))) {
                        // line 794
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 794), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 797
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/camping/" . twig_get_attribute($this->env, $this->source, $context["camping"], "imgPath", [], "any", false, false, false, 797))), "html", null, true);
                        echo "\" alt=\"camping.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 801
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 801), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 805
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("camping_like", ["id" => twig_get_attribute($this->env, $this->source, $context["camping"], "id", [], "any", false, false, false, 805)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-camping\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 806
                        if ((twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 806) && twig_get_attribute($this->env, $this->source, $context["camping"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 806)], "method", false, false, false, 806))) {
                            // line 807
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 809
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 811
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-camping\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["camping"], "likes", [], "any", false, false, false, 811)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 817
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['camping'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 818
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 819
            echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- end campoings-->
\t\t\t\t\t\t\t\t";
        }
        // line 824
        echo "\t\t\t\t\t\t\t\t<!-- start comntaire-->

\t\t\t\t\t\t\t\t<div id=\"cmnt\" class=\"destination_details_info \">
\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Comentaires</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-8 col-md-9 col-lg-12 \">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"destination_info\" id=\"comentaires\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 834
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["comentaires"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["comentaire"]) {
            // line 835
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comentaire"], "user", [], "any", false, false, false, 835), "nom", [], "any", false, false, false, 835), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 836
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comentaire"], "user", [], "any", false, false, false, 836), "prenom", [], "any", false, false, false, 836), "html", null, true);
            echo "</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>";
            // line 837
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comentaire"], "comentaire", [], "any", false, false, false, 837), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 838
            if ( !(null === twig_get_attribute($this->env, $this->source, $context["comentaire"], "image", [], "any", false, false, false, 838))) {
                // line 839
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height:200px; width:200px ;\" src=\"";
                // line 840
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("img/comentaire/" . twig_get_attribute($this->env, $this->source, $context["comentaire"], "image", [], "any", false, false, false, 840))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 843
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"border\" class=\"bordered_1px\"></div>

\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comentaire'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 846
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div id=\"Ali\" class=\"bordered_1px\"></div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"newletter_area overlay\">
\t\t\t\t\t\t\t\t\t<div class=\"container  d-flex justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t<form class=\"AjaxForm\" action=\"";
        // line 858
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("comentaire");
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_input\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"\" id=\"comentaire\" cols=\"30\" rows=\"7\" placeholder=\" votre comentaire\"></textarea>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"ville\" id=\"ville\" type=\"hidden\" value=\"";
        // line 865
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, ($context["ville"] ?? null), "id", [], "any", false, false, false, 865), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">

\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 869
        if (twig_get_attribute($this->env, $this->source, ($context["app"] ?? null), "user", [], "any", false, false, false, 869)) {
            // line 870
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"custom-file\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"file\" class=\"custom-file-input\" id=\"customFile\" accept=\"image/png, image/jpeg\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-file-label\" for=\"customFile\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tla  photo choisi</label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"boxed-btn4 \" type=\"submit\">Envoyer<i class=\"fa fa-send fa-tw cont-send\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 882
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_text\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>Pour faire un commentaire,  vous devez
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\têtre connecté ,
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-secondary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 888
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("comentaire");
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tici</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 895
        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<br><br><br>


\t\t\t\t\t\t\t\t<!-- end comntaire-->

\t\t\t\t\t\t\t";
    }

    // line 909
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        // line 910
        echo "\t\t\t\t\t\t\t   <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/like_hotel_camping_activite_resto_ajax.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t\t\t\t\t<script src=\"";
        // line 911
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/commentaire-ajax.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\t\t(function () {
document.querySelector('.AjaxForm').addEventListener('submit', function (e) {
e.preventDefault();
var formD = new FormData()
formD.append('comentaire', \$('#comentaire').val());
formD.append('ville', \$('#ville').val());
formD.append('file', document.getElementById('customFile').files[0]);
var contentType = {
headers: {
\"content-type\": \"multipart/form-data\"
}
};
axios.post(\$(\".AjaxForm\").attr('action'), formD, contentType).then(function (response) {
const \$error = response.data.error;
const newFilename = response.data.newFilename;
if (\$error == \"empty\" && newFilename == \"empty\") {
\$('#error').hide();
\$('#comentaires').append('<div id=\"error\"class=\"alert alert-danger\" role=\"alert\"><strong>il faut remplir au moin un champ !!</strong>');
} else {
const comentaire = response.data.comentaire;
const nom = response.data.nom;
const prenom = response.data.prenom;
\$('#comentaires').append(\"<h4>\" + nom + \" \" + prenom + \"</h4>\");
if (\$error != \"empty\") {
\$('#comentaires').append(\"<p>\" + comentaire + \"</h>\");
\$('#comentaire').val(\"\");
}
if (newFilename != \"empty\") {
const assetsBaseDir = \"";
        // line 941
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/comentaire/"), "html", null, true);
        echo "\";
\$('#comentaires').append('<div class=\"container\"><img style=\"height:200px; width:200px ;\" src=\"' + assetsBaseDir + newFilename + '\"></div>');
}
\$('#comentaires').append('<div id=\"border\" class=\"bordered_1px\"></div>');
\$('#error').hide();
}
}).catch(function (error) {
console.log(error);
});
});
})();
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t";
    }

    public function getTemplateName()
    {
        return "destination_details/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1421 => 941,  1388 => 911,  1383 => 910,  1379 => 909,  1363 => 895,  1353 => 888,  1345 => 882,  1331 => 870,  1329 => 869,  1322 => 865,  1312 => 858,  1298 => 846,  1290 => 843,  1284 => 840,  1281 => 839,  1279 => 838,  1275 => 837,  1271 => 836,  1266 => 835,  1262 => 834,  1250 => 824,  1243 => 819,  1237 => 818,  1231 => 817,  1221 => 811,  1217 => 809,  1213 => 807,  1211 => 806,  1207 => 805,  1200 => 801,  1193 => 797,  1186 => 794,  1183 => 793,  1178 => 792,  1174 => 791,  1162 => 781,  1160 => 780,  1155 => 777,  1148 => 772,  1142 => 771,  1136 => 770,  1124 => 762,  1120 => 760,  1116 => 758,  1114 => 757,  1110 => 756,  1103 => 752,  1096 => 748,  1089 => 745,  1086 => 744,  1081 => 743,  1077 => 742,  1065 => 732,  1063 => 731,  1058 => 728,  1052 => 724,  1046 => 723,  1040 => 722,  1027 => 713,  1023 => 711,  1019 => 709,  1017 => 708,  1013 => 707,  1006 => 703,  999 => 699,  992 => 696,  989 => 695,  984 => 694,  980 => 693,  968 => 683,  966 => 682,  961 => 679,  955 => 675,  949 => 674,  943 => 673,  930 => 664,  926 => 662,  922 => 660,  920 => 659,  916 => 658,  909 => 654,  900 => 650,  893 => 647,  890 => 646,  885 => 645,  881 => 644,  868 => 633,  866 => 632,  840 => 609,  820 => 592,  812 => 587,  808 => 586,  764 => 545,  476 => 260,  466 => 253,  455 => 245,  440 => 233,  411 => 207,  407 => 206,  401 => 202,  390 => 197,  385 => 195,  381 => 194,  376 => 191,  372 => 190,  369 => 189,  358 => 184,  353 => 182,  349 => 181,  344 => 178,  340 => 177,  337 => 176,  326 => 171,  321 => 169,  317 => 168,  312 => 165,  308 => 164,  305 => 163,  294 => 158,  289 => 156,  285 => 155,  280 => 152,  276 => 151,  260 => 137,  257 => 127,  250 => 123,  245 => 120,  238 => 116,  233 => 113,  231 => 112,  228 => 111,  221 => 107,  216 => 104,  209 => 100,  204 => 97,  202 => 96,  199 => 95,  192 => 91,  187 => 88,  180 => 84,  175 => 81,  173 => 80,  170 => 79,  163 => 75,  158 => 72,  151 => 68,  146 => 65,  144 => 64,  110 => 33,  95 => 20,  91 => 18,  87 => 16,  85 => 15,  81 => 14,  76 => 12,  70 => 10,  67 => 9,  65 => 8,  60 => 7,  56 => 6,  48 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("", "destination_details/index.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\destination_details\\index.html.twig");
    }
}
