<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* contact/index.html.twig */
class __TwigTemplate_0ebf005a827c15df589cc4c48d61e9c86cd69eac56f49b513c93073f787b9113 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "contact/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "contact/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello ContactController!";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 5
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 6
        echo "   ";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 6, $this->source); })()), "session", [], "any", false, false, false, 6), "set", [0 => "contact", 1 => "contact"], "method", false, false, false, 6), "html", null, true);
        echo "
     ";
        // line 7
        $context["v"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 7, $this->source); })()), "session", [], "any", false, false, false, 7), "remove", [0 => "ville"], "method", false, false, false, 7);
        // line 8
        echo "\t ";
        $context["d"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 8, $this->source); })()), "session", [], "any", false, false, false, 8), "remove", [0 => "destination"], "method", false, false, false, 8);
        // line 9
        echo "      <!-- bradcam_area  -->
     <div class=\"bradcam_area bradcam_bg_4\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-xl-12\">
                    <div class=\"bradcam_text text-center\">
                        <h3>contact</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ bradcam_area  -->

    <!-- ================ contact section start ================= -->
    <section class=\"contact-section\">
            <div class=\"container\">
                <div class=\"d-none d-sm-block mb-5 pb-4\">
                    <div id=\"map\" style=\"height: 480px; position: relative; overflow: hidden;\"> </div>
                    <script>
                        function initMap() {
                            var uluru = {
                                lat: 34.010116,
                                lng: -6.855120
                            };
                            var map = new google.maps.Map(document.getElementById('map'), {
                                center: uluru,
                                zoom: 6,
                                scrollwheel: false
                            });
                        }
                    </script>
                    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDpfS1oRGreGSBU5HHjMmQ3o5NLw7VdJ6I&amp;callback=initMap\">
                    </script>
    
                </div>

               ";
        // line 46
        if (0 === twig_compare((isset($context["result"]) || array_key_exists("result", $context) ? $context["result"] : (function () { throw new RuntimeError('Variable "result" does not exist.', 46, $this->source); })()), "succee")) {
            // line 47
            echo "                  <div class=\"container\">
                    <div class=\"alert alert-primary\" role=\"alert\">
                        <strong>le messsage a bien ete  envoye!</strong>
                     </div>
                  </div>
              ";
        }
        // line 53
        echo "                ";
        if (0 === twig_compare((isset($context["result"]) || array_key_exists("result", $context) ? $context["result"] : (function () { throw new RuntimeError('Variable "result" does not exist.', 53, $this->source); })()), "vide")) {
            // line 54
            echo "                  <div class=\"container\">
                    <div class=\"alert alert-danger\" role=\"alert\">
                        <strong>erreur</strong>
                     </div>
                  </div>
              ";
        }
        // line 60
        echo "              
                <div class=\"row\">
                    <div class=\"col-12\">
                        <h2 class=\"contact-title\">contact</h2>
                    </div>
                    <div class=\"col-lg-8\">
                        <form class=\"form-contact contact_form\" action=\"";
        // line 66
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("send_email");
        echo "\" method=\"post\" id=\"contactForm\" novalidate=\"novalidate\">
                            <div class=\"row\">
                                <div class=\"col-12\">
                                    <div class=\"form-group\">
                                        <textarea class=\"form-control w-100\" name=\"message\" id=\"message\" placeholder=\" Entre votre Message\" required ></textarea>
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control valid\" name=\"name\" id=\"name\" type=\"text\"  placeholder=\"Entre votre nom\" required >
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control valid\" name=\"email\" id=\"email\" type=\"email\"  placeholder=\"Email\" required>
                                    </div>
                                </div>
                                <div class=\"col-12\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control \" name=\"subject\" id=\"subject\" type=\"text\"  placeholder=\"Entre votre sujet\" required>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group mt-3\">
                                <button type=\"submit\" class=\"button button-contactForm boxed-btn\">Envoyer</button>
                            </div>
                        </form>
                    </div>
         
                </div>
            </div>
        </section>
    <!-- ================ contact section end ================= -->
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "contact/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  166 => 66,  158 => 60,  150 => 54,  147 => 53,  139 => 47,  137 => 46,  98 => 9,  95 => 8,  93 => 7,  88 => 6,  78 => 5,  59 => 3,  36 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello ContactController!{% endblock %}

{% block body %}
   {{ app.session.set('contact','contact')}}
     {% set v = app.session.remove('ville')%}
\t {% set d = app.session.remove('destination')%}
      <!-- bradcam_area  -->
     <div class=\"bradcam_area bradcam_bg_4\">
        <div class=\"container\">
            <div class=\"row\">
                <div class=\"col-xl-12\">
                    <div class=\"bradcam_text text-center\">
                        <h3>contact</h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!--/ bradcam_area  -->

    <!-- ================ contact section start ================= -->
    <section class=\"contact-section\">
            <div class=\"container\">
                <div class=\"d-none d-sm-block mb-5 pb-4\">
                    <div id=\"map\" style=\"height: 480px; position: relative; overflow: hidden;\"> </div>
                    <script>
                        function initMap() {
                            var uluru = {
                                lat: 34.010116,
                                lng: -6.855120
                            };
                            var map = new google.maps.Map(document.getElementById('map'), {
                                center: uluru,
                                zoom: 6,
                                scrollwheel: false
                            });
                        }
                    </script>
                    <script src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyDpfS1oRGreGSBU5HHjMmQ3o5NLw7VdJ6I&amp;callback=initMap\">
                    </script>
    
                </div>

               {% if result==\"succee\" %}
                  <div class=\"container\">
                    <div class=\"alert alert-primary\" role=\"alert\">
                        <strong>le messsage a bien ete  envoye!</strong>
                     </div>
                  </div>
              {% endif %}
                {% if result==\"vide\"   %}
                  <div class=\"container\">
                    <div class=\"alert alert-danger\" role=\"alert\">
                        <strong>erreur</strong>
                     </div>
                  </div>
              {% endif %}
              
                <div class=\"row\">
                    <div class=\"col-12\">
                        <h2 class=\"contact-title\">contact</h2>
                    </div>
                    <div class=\"col-lg-8\">
                        <form class=\"form-contact contact_form\" action=\"{{path('send_email')}}\" method=\"post\" id=\"contactForm\" novalidate=\"novalidate\">
                            <div class=\"row\">
                                <div class=\"col-12\">
                                    <div class=\"form-group\">
                                        <textarea class=\"form-control w-100\" name=\"message\" id=\"message\" placeholder=\" Entre votre Message\" required ></textarea>
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control valid\" name=\"name\" id=\"name\" type=\"text\"  placeholder=\"Entre votre nom\" required >
                                    </div>
                                </div>
                                <div class=\"col-sm-6\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control valid\" name=\"email\" id=\"email\" type=\"email\"  placeholder=\"Email\" required>
                                    </div>
                                </div>
                                <div class=\"col-12\">
                                    <div class=\"form-group\">
                                        <input class=\"form-control \" name=\"subject\" id=\"subject\" type=\"text\"  placeholder=\"Entre votre sujet\" required>
                                    </div>
                                </div>
                            </div>
                            <div class=\"form-group mt-3\">
                                <button type=\"submit\" class=\"button button-contactForm boxed-btn\">Envoyer</button>
                            </div>
                        </form>
                    </div>
         
                </div>
            </div>
        </section>
    <!-- ================ contact section end ================= -->
{% endblock %}
", "contact/index.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\contact\\index.html.twig");
    }
}
