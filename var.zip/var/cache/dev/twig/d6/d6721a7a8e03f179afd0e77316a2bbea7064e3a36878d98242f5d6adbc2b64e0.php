<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* destination_details/index.html.twig */
class __TwigTemplate_ae52e3afccd9234d68a045c6c5568b7412b3094b4802911aafbf73d8d579fae6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'title' => [$this, 'block_title'],
            'body' => [$this, 'block_body'],
            'javascripts' => [$this, 'block_javascripts'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "base.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "destination_details/index.html.twig"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "destination_details/index.html.twig"));

        $this->parent = $this->loadTemplate("base.html.twig", "destination_details/index.html.twig", 1);
        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

    }

    // line 3
    public function block_title($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "title"));

        echo "Hello DestinationDetailsController!
";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 6
    public function block_body($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "body"));

        // line 7
        echo "\t";
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 7, $this->source); })()), "session", [], "any", false, false, false, 7), "set", [0 => "ville", 1 => twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 7, $this->source); })()), "name", [], "any", false, false, false, 7)], "method", false, false, false, 7), "html", null, true);
        echo "
\t";
        // line 8
        $context["d"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 8, $this->source); })()), "session", [], "any", false, false, false, 8), "remove", [0 => "destination"], "method", false, false, false, 8);
        // line 9
        echo "\t";
        $context["c"] = twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 9, $this->source); })()), "session", [], "any", false, false, false, 9), "remove", [0 => "contact"], "method", false, false, false, 9);
        // line 10
        echo "\t<div class=\"destination_banner_wrap overlay\" style=\"background-image:url(";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/place/" . twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 10, $this->source); })()), "image", [], "any", false, false, false, 10))), "html", null, true);
        echo ");\">
\t\t<div class=\"destination_text text-center\">
\t\t\t<h3>";
        // line 12
        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 12, $this->source); })()), "name", [], "any", false, false, false, 12), ["_" => " "]), "html", null, true);
        echo "</h3>
\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t<a href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("ville_like", ["id" => twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 14, $this->source); })()), "id", [], "any", false, false, false, 14)]), "html", null, true);
        echo "\" class=\"btn btn-link js-like\">
\t\t\t\t\t";
        // line 15
        if ((twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 15, $this->source); })()), "user", [], "any", false, false, false, 15) && twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 15, $this->source); })()), "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 15, $this->source); })()), "user", [], "any", false, false, false, 15)], "method", false, false, false, 15))) {
            // line 16
            echo "\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x \" style=\" color: red;\"></i>
\t\t\t\t\t";
        } else {
            // line 18
            echo "\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\" style=\" color: red;\"></i>
\t\t\t\t\t";
        }
        // line 20
        echo "
\t\t\t\t</a>
\t\t\t</span>
\t\t</div>
\t</div>
\t<!-- start description-->
\t<div class=\"destination_details_info\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t<div class=\"col-lg-8 col-md-9\">
\t\t\t\t\t<div class=\"destination_info\">

\t\t\t\t\t\t<h3>Description</h3>
\t\t\t\t\t\t";
        // line 33
        echo twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 33, $this->source); })()), "description", [], "any", false, false, false, 33);
        echo "
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"bordered_1px\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- end description-->

\t<div class=\"row justify-content-center\">
\t\t<div class=\"col-lg-6\">
\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t<h3>La carte</h3>
\t\t\t</div>
\t\t</div>
\t</div>


\t<!-- start map-->
\t<div class=\"container\">
\t\t<div class=\"d-none d-sm-block mb-5 pb-4\">
\t\t\t<div id=\"map\" style=\"height: 480px; width: 770px; position: relative;\"></div>


\t\t\t<div class=\"col-lg-4\" style=\" left: 790px; top: -480px;\">
\t\t\t\t<div class=\"filter_result_wrap\">
\t\t\t\t\t<h3>Filter de résultats</h3>
\t\t\t\t\t<div class=\"filter_bordered\">
\t\t\t\t\t\t<div class=\"filter_inner\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<form class=\"was-validated\">
\t\t\t\t\t\t\t\t\t";
        // line 64
        if ( !twig_test_empty((isset($context["hotelMarkers"]) || array_key_exists("hotelMarkers", $context) ? $context["hotelMarkers"] : (function () { throw new RuntimeError('Variable "hotelMarkers" does not exist.', 64, $this->source); })()))) {
            // line 65
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 68
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 72
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 75
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 79
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 80
        if ( !twig_test_empty((isset($context["restoMarkers"]) || array_key_exists("restoMarkers", $context) ? $context["restoMarkers"] : (function () { throw new RuntimeError('Variable "restoMarkers" does not exist.', 80, $this->source); })()))) {
            // line 81
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 84
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 88
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 91
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 95
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 96
        if ( !twig_test_empty((isset($context["activiteMarkers"]) || array_key_exists("activiteMarkers", $context) ? $context["activiteMarkers"] : (function () { throw new RuntimeError('Variable "activiteMarkers" does not exist.', 96, $this->source); })()))) {
            // line 97
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 100
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 104
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 107
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 111
        echo "
\t\t\t\t\t\t\t\t\t";
        // line 112
        if ( !twig_test_empty((isset($context["campingMarkers"]) || array_key_exists("campingMarkers", $context) ? $context["campingMarkers"] : (function () { throw new RuntimeError('Variable "campingMarkers" does not exist.', 112, $this->source); })()))) {
            // line 113
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 116
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        } else {
            // line 120
            echo "\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='";
            // line 123
            echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent30.png"), "html", null, true);
            echo "' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t";
        }
        // line 127
        echo "\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t";
        // line 137
        echo "\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<script language=\"JavaScript\" type=\"text/javascript\" src=\"/js/vendor/jquery-1.12.4.min.js\"></script>


\t\t\t<script>
\t\t\t\tvar hotelMarkers = [];
var campingMarkers = [];
var restoMarkers = [];
var activiteMarkers = [];
\t\t\t</script>
\t\t\t";
        // line 151
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["hotelMarkers"]) || array_key_exists("hotelMarkers", $context) ? $context["hotelMarkers"] : (function () { throw new RuntimeError('Variable "hotelMarkers" does not exist.', 151, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["hotelMarker"]) {
            // line 152
            echo "\t\t\t\t<script>
\t\t\t\t\tvar hotelMarker = {
position: {
lat: ";
            // line 155
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "lat", [], "any", false, false, false, 155), "html", null, true);
            echo ",
lng: ";
            // line 156
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "lng", [], "any", false, false, false, 156), "html", null, true);
            echo "
},
title: \"";
            // line 158
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["hotelMarker"], "name", [], "any", false, false, false, 158), [" " => "_"]), "html", null, true);
            echo "\"
};
hotelMarkers.push(hotelMarker);
\t\t\t\t</script>
\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotelMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 163
        echo "
\t\t\t\t";
        // line 164
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["campingMarkers"]) || array_key_exists("campingMarkers", $context) ? $context["campingMarkers"] : (function () { throw new RuntimeError('Variable "campingMarkers" does not exist.', 164, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["campingMarker"]) {
            // line 165
            echo "\t\t\t\t\t<script>
\t\t\t\t\t\tvar campingMarker = {
position: {
lat: ";
            // line 168
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["campingMarker"], "lat", [], "any", false, false, false, 168), "html", null, true);
            echo ",
lng: ";
            // line 169
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["campingMarker"], "lng", [], "any", false, false, false, 169), "html", null, true);
            echo "
},
title: \"";
            // line 171
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["campingMarker"], "name", [], "any", false, false, false, 171), [" " => "_"]), "html", null, true);
            echo "\"
};
campingMarkers.push(campingMarker);
\t\t\t\t\t</script>
\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['campingMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 176
        echo "
\t\t\t\t\t";
        // line 177
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["activiteMarkers"]) || array_key_exists("activiteMarkers", $context) ? $context["activiteMarkers"] : (function () { throw new RuntimeError('Variable "activiteMarkers" does not exist.', 177, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["activiteMarker"]) {
            // line 178
            echo "\t\t\t\t\t\t<script>
\t\t\t\t\t\t\tvar activiteMarker = {
position: {
lat: ";
            // line 181
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "lat", [], "any", false, false, false, 181), "html", null, true);
            echo ",
lng: ";
            // line 182
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "lng", [], "any", false, false, false, 182), "html", null, true);
            echo "
},
title: \"";
            // line 184
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["activiteMarker"], "name", [], "any", false, false, false, 184), [" " => "_"]), "html", null, true);
            echo "\"
};
activiteMarkers.push(activiteMarker);
\t\t\t\t\t\t</script>
\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activiteMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 189
        echo "
\t\t\t\t\t\t";
        // line 190
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["restoMarkers"]) || array_key_exists("restoMarkers", $context) ? $context["restoMarkers"] : (function () { throw new RuntimeError('Variable "restoMarkers" does not exist.', 190, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["restoMarker"]) {
            // line 191
            echo "\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tvar restoMarker = {
position: {
lat: ";
            // line 194
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["restoMarker"], "lat", [], "any", false, false, false, 194), "html", null, true);
            echo ",
lng: ";
            // line 195
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["restoMarker"], "lng", [], "any", false, false, false, 195), "html", null, true);
            echo "
},
title: \"";
            // line 197
            echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["restoMarker"], "name", [], "any", false, false, false, 197), [" " => "_"]), "html", null, true);
            echo "\"
};
restoMarkers.push(restoMarker);
\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['restoMarker'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 202
        echo "
\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tfunction initMap() {
var uluru = {
lat: ";
        // line 206
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["villeMarker"]) || array_key_exists("villeMarker", $context) ? $context["villeMarker"] : (function () { throw new RuntimeError('Variable "villeMarker" does not exist.', 206, $this->source); })()), "lat", [], "any", false, false, false, 206), "html", null, true);
        echo ",
lng: ";
        // line 207
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["villeMarker"]) || array_key_exists("villeMarker", $context) ? $context["villeMarker"] : (function () { throw new RuntimeError('Variable "villeMarker" does not exist.', 207, $this->source); })()), "lng", [], "any", false, false, false, 207), "html", null, true);
        echo "
};

var map = new google.maps.Map(document.getElementById('map'), {
zoom: 13,
center: uluru,
scrollwheel: true, /*mapTypeId: 'satellite'*/
mapTypeId: google.maps.MapTypeId.ROADMAP
});
var marker = new google.maps.Marker({
position: uluru, map: map, clickable: true, animation: google.maps.Animation.BOUNCE /*DROP*/
});
marker.setTitle(\"cmnt\");
marker.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + marker.getTitle()).offset().top
}, 'slow');
});

var markers = [];

for (let i = 0; i < hotelMarkers.length; i++) {
var mh = new google.maps.Marker({
position: hotelMarkers[i].position, map: map,
// label: \"H\",
icon: {
url: '";
        // line 233
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/hotel_50.png"), "html", null, true);
        echo "'
}
});
mh.setTitle(hotelMarkers[i].title);

markers.push(mh);
}

for (let i = 0; i < restoMarkers.length; i++) {
var mr = new google.maps.Marker({
position: restoMarkers[i].position, map: map,
// label: \"R\"
icon: '";
        // line 245
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/resto_50.png"), "html", null, true);
        echo "'
});
mr.setTitle(restoMarkers[i].title);

markers.push(mr);
}

for (let i = 0; i < campingMarkers.length; i++) {
var mc = new google.maps.Marker({position: campingMarkers[i].position, map: map, icon: '";
        // line 253
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/tent50.png"), "html", null, true);
        echo "'});
mc.setTitle(campingMarkers[i].title);

markers.push(mc);
}

for (let i = 0; i < activiteMarkers.length; i++) {
var ma = new google.maps.Marker({position: activiteMarkers[i].position, map: map, icon: '";
        // line 260
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/marker_icon/activite50.png"), "html", null, true);
        echo "'});
ma.setTitle(activiteMarkers[i].title);

markers.push(ma);
}

var infowindow = new google.maps.InfoWindow();
markers.map((m) => {
m.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + m.getTitle()).offset().top
}, 'slow');
\$(\"#\" + m.getTitle()).hide(1100);
\$(\"#\" + m.getTitle()).show(2000);
// \$(\"#\" + m.getTitle()).animate({height: '+=20%'});


});

m.addListener('mouseover', function () {
infowindow.setContent(m.getTitle());
infowindow.open(map, m);
});
});

\$(\"#customControlValidation1\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation3\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation2\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation4\").change(function () {
if (this.checked) {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

}
\t\t\t\t\t\t\t</script>

\t\t\t\t\t\t\t<script async defer src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyCmC9pqdr3_Wbb9jGSl9EBKNNNAhcA6puE&callback=initMap\"></script>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<!-- end description-->

\t\t\t\t\t<!-- Start meteo -->
\t\t\t\t\t<style type=\"text/css\">
\t\t\t\t\t\t@import url(https://fonts.googleapis.com/css?family=Roboto:400,300);
\t\t\t\t\t\t{
\t\t\t\t\t\t\t# html,
\t\t\t\t\t\t\tbody {
\t\t\t\t\t\t\t\tbackground-color: #F3F3F3;
\t\t\t\t\t\t\t\tfont-family: 'Roboto', sans-serif;
\t\t\t\t\t\t\t} #
\t\t\t\t\t\t}

\t\t\t\t\t\t.card {
\t\t\t\t\t\t\tmargin: 5% auto 0;
\t\t\t\t\t\t\tpadding: 5px 30px;
\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\tborder-radius: 3px;
\t\t\t\t\t\t\tbackground-color: #fff;
\t\t\t\t\t\t\tbox-shadow: 1px 2px 10px rgba(0, 0, 0, 0.2);
\t\t\t\t\t\t\t-webkit-animation: open 2s cubic-bezier(0.39, 0, 0.38, 1);
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes open {
\t\t\t\t\t\t\tfrom {
\t\t\t\t\t\t\t\tpadding: 0 30px;
\t\t\t\t\t\t\t\theight: 0;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\tto {
\t\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}

\t\t\t\t\t\th1,
\t\t\t\t\t\th2,
\t\t\t\t\t\th3,
\t\t\t\t\t\th4 {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t}

\t\t\t\t\t\t.dot {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sky {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\tmargin-top: 108px;
\t\t\t\t\t\t\twidth: 100px;
\t\t\t\t\t\t\theight: 100px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #03A9F4;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sun {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: -3px;
\t\t\t\t\t\t\twidth: 55px;
\t\t\t\t\t\t\theight: 55px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #FFEB3B;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.5s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: 60px;
\t\t\t\t\t\t\tleft: 30px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before,
\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\tdisplay: block;
\t\t\t\t\t\t\tcontent: \"\";
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before {
\t\t\t\t\t\t\tmargin-left: -10px;
\t\t\t\t\t\t\twidth: 51px;
\t\t\t\t\t\t\theight: 18px;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: -10px;
\t\t\t\t\t\t\tleft: -22px;
\t\t\t\t\t\t\twidth: 28px;
\t\t\t\t\t\t\theight: 28px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t\tbox-shadow: 50px -6px 0 6px #fff, 25px -19px 0 10px #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\ttable {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: 10px;
\t\t\t\t\t\t\twidth: 100%;
\t\t\t\t\t\t\ttext-align: center;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(1) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 32px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tcolor: #999;
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes up {
\t\t\t\t\t\t\t0% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t50% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t99% {
\t\t\t\t\t\t\t\t-webkit-animation-play-state: paused;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t100% {
\t\t\t\t\t\t\t\topacity: 1;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t</style>
\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t<h3>La Meteo</h3>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-5\">
\t\t\t\t\t\t\t\t\t<div class=\"card\">

\t\t\t\t\t\t\t\t\t\t<h2 style=\"font-weight: 300; font-size: 2.25em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1); \">";
        // line 545
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 545, $this->source); })()), "name", [], "any", false, false, false, 545), "html", null, true);
        echo "</h2>
\t\t\t\t\t\t\t\t\t\t<h3 id=\"day0\" style=\"float: right; left: 260px; top: -47px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\"></h3>
\t\t\t\t\t\t\t\t\t\t<h3 style=\"float: left; margin-right: 33px; top: 0px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\" id=\"desc\"></h3>
\t\t\t\t\t\t\t\t\t\t<h1 id=\"temp\" style=\"float: right; color: #666; font-weight: 300; top: 32px; font-size: 6.59375em; line-height: 0.2em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;\">&deg;</h1>
\t\t\t\t\t\t\t\t\t\t<div id=\"sky\"></div>
\t\t\t\t\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<script>
\t\t\t\t\t\tvar lat = ";
        // line 586
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["villeMarker"]) || array_key_exists("villeMarker", $context) ? $context["villeMarker"] : (function () { throw new RuntimeError('Variable "villeMarker" does not exist.', 586, $this->source); })()), "lat", [], "any", false, false, false, 586), "html", null, true);
        echo ";
var lng = ";
        // line 587
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["villeMarker"]) || array_key_exists("villeMarker", $context) ? $context["villeMarker"] : (function () { throw new RuntimeError('Variable "villeMarker" does not exist.', 587, $this->source); })()), "lng", [], "any", false, false, false, 587), "html", null, true);
        echo ";

fetch('https://api.openweathermap.org/data/2.5/onecall?lat=' + lat + '&lon=' + lng + '&units=metric&appid=7215d0713dbd93f757a51b198da702cc').then(response => response.json()).then(data => {
console.log(data);
document.getElementById(\"temp\").innerHTML = data.current.temp + '&deg;';
document.getElementById(\"sky\").innerHTML = '<img src=' + '";
        // line 592
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/weather/"), "html", null, true);
        echo "' + data.daily[0].weather[0].icon + '.png' + '>';

document.getElementById(\"desc\").innerHTML = data.current.weather[0].description + '<span  id=\"wind\" style=\"margin-left: 24px; color: #999; font-weight: 300;\">Vent ' + data.current.wind_speed + 'm/s <span style=\"margin-left: 0;\" class=\"dot\">•</span> humidité ' + data.current.humidity + '%</span>';

var date0 = new Date();
let dateLocale0 = date0.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});

document.getElementById(\"day0\").innerHTML = dateLocale0;

for (var i = 1; i < 6; i++) {
document.getElementById(\"tempMaxd\" + i).innerHTML = data.daily[i].temp.max + '&deg;';

document.getElementById(\"icond\" + i).innerHTML = '<img style=\"width: 65px\" src=' +'";
        // line 609
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/weather/"), "html", null, true);
        echo "' + data.daily[i].weather[0].icon + '.png' + '>';

document.getElementById(\"tempMind\" + i).innerHTML = data.daily[i].temp.min + '&deg;';


var date = new Date();
date.setDate(new Date().getDate() + i);
let dateLocale = date.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});
document.getElementById(\"day\" + i).innerHTML = dateLocale.substr(0, 3).toUpperCase();

}

});
\t\t\t\t\t</script>

\t\t\t\t\t<!-- End meteo -->


\t\t\t\t\t";
        // line 632
        if (( !twig_test_empty((isset($context["hotels"]) || array_key_exists("hotels", $context) ? $context["hotels"] : (function () { throw new RuntimeError('Variable "hotels" does not exist.', 632, $this->source); })())) &&  !twig_test_empty((isset($context["hotelMarkers"]) || array_key_exists("hotelMarkers", $context) ? $context["hotelMarkers"] : (function () { throw new RuntimeError('Variable "hotelMarkers" does not exist.', 632, $this->source); })())))) {
            // line 633
            echo "\t\t\t\t\t\t<!-- start hotels-->
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Hotels</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 644
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["hotelMarkers"]) || array_key_exists("hotelMarkers", $context) ? $context["hotelMarkers"] : (function () { throw new RuntimeError('Variable "hotelMarkers" does not exist.', 644, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 645
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["hotels"]) || array_key_exists("hotels", $context) ? $context["hotels"] : (function () { throw new RuntimeError('Variable "hotels" does not exist.', 645, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["hotel"]) {
                    // line 646
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 646), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["hotel"], "nom", [], "any", false, false, false, 646), [" " => "_"]))) {
                        // line 647
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 647), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"";
                        // line 650
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/hotel/" . twig_get_attribute($this->env, $this->source, $context["hotel"], "imgPath", [], "any", false, false, false, 650))), "html", null, true);
                        echo "\" alt=";
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotel"], "nom", [], "any", false, false, false, 650), "html", null, true);
                        echo ">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 654
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 654), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 658
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("hotel_like", ["id" => twig_get_attribute($this->env, $this->source, $context["hotel"], "id", [], "any", false, false, false, 658)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-hotel\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 659
                        if ((twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 659, $this->source); })()), "user", [], "any", false, false, false, 659) && twig_get_attribute($this->env, $this->source, $context["hotel"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 659, $this->source); })()), "user", [], "any", false, false, false, 659)], "method", false, false, false, 659))) {
                            // line 660
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 662
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 664
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-hotel\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["hotel"], "likes", [], "any", false, false, false, 664)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 673
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['hotel'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 674
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 675
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 679
        echo "\t\t\t\t\t<!-- end hotels-->

\t\t\t\t\t<!-- start Restaurants-->
\t\t\t\t\t";
        // line 682
        if ( !twig_test_empty((isset($context["restos"]) || array_key_exists("restos", $context) ? $context["restos"] : (function () { throw new RuntimeError('Variable "restos" does not exist.', 682, $this->source); })()))) {
            // line 683
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Restaurants</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 693
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["restoMarkers"]) || array_key_exists("restoMarkers", $context) ? $context["restoMarkers"] : (function () { throw new RuntimeError('Variable "restoMarkers" does not exist.', 693, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 694
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["restos"]) || array_key_exists("restos", $context) ? $context["restos"] : (function () { throw new RuntimeError('Variable "restos" does not exist.', 694, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["resto"]) {
                    // line 695
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 695), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["resto"], "nom", [], "any", false, false, false, 695), [" " => "_"]))) {
                        // line 696
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 696), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 699
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/resto/" . twig_get_attribute($this->env, $this->source, $context["resto"], "imgPath", [], "any", false, false, false, 699))), "html", null, true);
                        echo "\" alt=\"resto.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 703
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 703), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 707
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("resto_like", ["id" => twig_get_attribute($this->env, $this->source, $context["resto"], "id", [], "any", false, false, false, 707)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-resto\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 708
                        if ((twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 708, $this->source); })()), "user", [], "any", false, false, false, 708) && twig_get_attribute($this->env, $this->source, $context["resto"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 708, $this->source); })()), "user", [], "any", false, false, false, 708)], "method", false, false, false, 708))) {
                            // line 709
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 711
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 713
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-resto\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["resto"], "likes", [], "any", false, false, false, 713)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 722
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['resto'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 723
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 724
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t";
        }
        // line 728
        echo "\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start activite-->
\t\t\t\t\t";
        // line 731
        if ( !twig_test_empty((isset($context["activites"]) || array_key_exists("activites", $context) ? $context["activites"] : (function () { throw new RuntimeError('Variable "activites" does not exist.', 731, $this->source); })()))) {
            // line 732
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Activités</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 742
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["activiteMarkers"]) || array_key_exists("activiteMarkers", $context) ? $context["activiteMarkers"] : (function () { throw new RuntimeError('Variable "activiteMarkers" does not exist.', 742, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 743
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["activites"]) || array_key_exists("activites", $context) ? $context["activites"] : (function () { throw new RuntimeError('Variable "activites" does not exist.', 743, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["activite"]) {
                    // line 744
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 744), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["activite"], "nom", [], "any", false, false, false, 744), [" " => "_"]))) {
                        // line 745
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 745), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 748
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/activite/" . twig_get_attribute($this->env, $this->source, $context["activite"], "imgPath", [], "any", false, false, false, 748))), "html", null, true);
                        echo "\" alt=\"activite.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 752
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 752), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 756
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("activite_like", ["id" => twig_get_attribute($this->env, $this->source, $context["activite"], "id", [], "any", false, false, false, 756)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-activite\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 757
                        if ((twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 757, $this->source); })()), "user", [], "any", false, false, false, 757) && twig_get_attribute($this->env, $this->source, $context["activite"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 757, $this->source); })()), "user", [], "any", false, false, false, 757)], "method", false, false, false, 757))) {
                            // line 758
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 760
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 762
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-activite\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["activite"], "likes", [], "any", false, false, false, 762)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 770
                    echo "\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['activite'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 771
                echo "\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 772
            echo "\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t";
        }
        // line 777
        echo "\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start campings-->
\t\t\t\t\t";
        // line 780
        if ( !twig_test_empty((isset($context["campings"]) || array_key_exists("campings", $context) ? $context["campings"] : (function () { throw new RuntimeError('Variable "campings" does not exist.', 780, $this->source); })()))) {
            // line 781
            echo "\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Campings</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t";
            // line 791
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable((isset($context["campingMarkers"]) || array_key_exists("campingMarkers", $context) ? $context["campingMarkers"] : (function () { throw new RuntimeError('Variable "campingMarkers" does not exist.', 791, $this->source); })()));
            foreach ($context['_seq'] as $context["_key"] => $context["marker"]) {
                // line 792
                echo "\t\t\t\t\t\t\t\t\t\t";
                $context['_parent'] = $context;
                $context['_seq'] = twig_ensure_traversable((isset($context["campings"]) || array_key_exists("campings", $context) ? $context["campings"] : (function () { throw new RuntimeError('Variable "campings" does not exist.', 792, $this->source); })()));
                foreach ($context['_seq'] as $context["_key"] => $context["camping"]) {
                    // line 793
                    echo "\t\t\t\t\t\t\t\t\t\t\t";
                    if (0 === twig_compare(twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 793), [" " => "_"]), twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["camping"], "nom", [], "any", false, false, false, 793), [" " => "_"]))) {
                        // line 794
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t<div id=";
                        echo twig_escape_filter($this->env, twig_replace_filter(twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 794), [" " => "_"]), "html", null, true);
                        echo " class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"";
                        // line 797
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("/img/camping/" . twig_get_attribute($this->env, $this->source, $context["camping"], "imgPath", [], "any", false, false, false, 797))), "html", null, true);
                        echo "\" alt=\"camping.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>";
                        // line 801
                        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["marker"], "name", [], "any", false, false, false, 801), "html", null, true);
                        echo "</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
                        // line 805
                        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("camping_like", ["id" => twig_get_attribute($this->env, $this->source, $context["camping"], "id", [], "any", false, false, false, 805)]), "html", null, true);
                        echo "\" class=\"btn btn-link js-like-camping\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        // line 806
                        if ((twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 806, $this->source); })()), "user", [], "any", false, false, false, 806) && twig_get_attribute($this->env, $this->source, $context["camping"], "isLikedByUser", [0 => twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 806, $this->source); })()), "user", [], "any", false, false, false, 806)], "method", false, false, false, 806))) {
                            // line 807
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        } else {
                            // line 809
                            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                        }
                        // line 811
                        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-camping\">";
                        echo twig_escape_filter($this->env, twig_length_filter($this->env, twig_get_attribute($this->env, $this->source, $context["camping"], "likes", [], "any", false, false, false, 811)), "html", null, true);
                        echo "</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
                    }
                    // line 817
                    echo "\t\t\t\t\t\t\t\t\t\t\t\t\t";
                }
                $_parent = $context['_parent'];
                unset($context['_seq'], $context['_iterated'], $context['_key'], $context['camping'], $context['_parent'], $context['loop']);
                $context = array_intersect_key($context, $_parent) + $_parent;
                // line 818
                echo "\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['_key'], $context['marker'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
            // line 819
            echo "\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- end campoings-->
\t\t\t\t\t\t\t\t";
        }
        // line 824
        echo "\t\t\t\t\t\t\t\t<!-- start comntaire-->

\t\t\t\t\t\t\t\t<div id=\"cmnt\" class=\"destination_details_info \">
\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Comentaires</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-8 col-md-9 col-lg-12 \">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"destination_info\" id=\"comentaires\">
\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 834
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable((isset($context["comentaires"]) || array_key_exists("comentaires", $context) ? $context["comentaires"] : (function () { throw new RuntimeError('Variable "comentaires" does not exist.', 834, $this->source); })()));
        foreach ($context['_seq'] as $context["_key"] => $context["comentaire"]) {
            // line 835
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4>";
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comentaire"], "user", [], "any", false, false, false, 835), "nom", [], "any", false, false, false, 835), "html", null, true);
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 836
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, twig_get_attribute($this->env, $this->source, $context["comentaire"], "user", [], "any", false, false, false, 836), "prenom", [], "any", false, false, false, 836), "html", null, true);
            echo "</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>";
            // line 837
            echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, $context["comentaire"], "comentaire", [], "any", false, false, false, 837), "html", null, true);
            echo "</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            // line 838
            if ( !(null === twig_get_attribute($this->env, $this->source, $context["comentaire"], "image", [], "any", false, false, false, 838))) {
                // line 839
                echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height:200px; width:200px ;\" src=\"";
                // line 840
                echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl(("img/comentaire/" . twig_get_attribute($this->env, $this->source, $context["comentaire"], "image", [], "any", false, false, false, 840))), "html", null, true);
                echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
            }
            // line 843
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"border\" class=\"bordered_1px\"></div>

\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['comentaire'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 846
        echo "\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div id=\"Ali\" class=\"bordered_1px\"></div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"newletter_area overlay\">
\t\t\t\t\t\t\t\t\t<div class=\"container  d-flex justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t<form class=\"AjaxForm\" action=\"";
        // line 858
        echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("comentaire");
        echo "\" method=\"post\" enctype=\"multipart/form-data\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_input\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"\" id=\"comentaire\" cols=\"30\" rows=\"7\" placeholder=\" votre comentaire\"></textarea>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"ville\" id=\"ville\" type=\"hidden\" value=\"";
        // line 865
        echo twig_escape_filter($this->env, twig_get_attribute($this->env, $this->source, (isset($context["ville"]) || array_key_exists("ville", $context) ? $context["ville"] : (function () { throw new RuntimeError('Variable "ville" does not exist.', 865, $this->source); })()), "id", [], "any", false, false, false, 865), "html", null, true);
        echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">

\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        // line 869
        if (twig_get_attribute($this->env, $this->source, (isset($context["app"]) || array_key_exists("app", $context) ? $context["app"] : (function () { throw new RuntimeError('Variable "app" does not exist.', 869, $this->source); })()), "user", [], "any", false, false, false, 869)) {
            // line 870
            echo "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"custom-file\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"file\" class=\"custom-file-input\" id=\"customFile\" accept=\"image/png, image/jpeg\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-file-label\" for=\"customFile\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tla  photo choisi</label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"boxed-btn4 \" type=\"submit\">Envoyer<i class=\"fa fa-send fa-tw cont-send\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        } else {
            // line 882
            echo "
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_text\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>Pour faire un commentaire,  vous devez
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\têtre connecté ,
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-secondary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"";
            // line 888
            echo $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("comentaire");
            echo "\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tici</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t";
        }
        // line 895
        echo "\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<br><br><br>


\t\t\t\t\t\t\t\t<!-- end comntaire-->

\t\t\t\t\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    // line 909
    public function block_javascripts($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e = $this->extensions["Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension"];
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->enter($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02 = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->enter($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "javascripts"));

        // line 910
        echo "\t\t\t\t\t\t\t   <script src=\"";
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/like_hotel_camping_activite_resto_ajax.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t\t\t\t\t<script src=\"";
        // line 911
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("js/commentaire-ajax.js"), "html", null, true);
        echo "\"></script>
\t\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\t\t(function () {
document.querySelector('.AjaxForm').addEventListener('submit', function (e) {
e.preventDefault();
var formD = new FormData()
formD.append('comentaire', \$('#comentaire').val());
formD.append('ville', \$('#ville').val());
formD.append('file', document.getElementById('customFile').files[0]);
var contentType = {
headers: {
\"content-type\": \"multipart/form-data\"
}
};
axios.post(\$(\".AjaxForm\").attr('action'), formD, contentType).then(function (response) {
const \$error = response.data.error;
const newFilename = response.data.newFilename;
if (\$error == \"empty\" && newFilename == \"empty\") {
\$('#error').hide();
\$('#comentaires').append('<div id=\"error\"class=\"alert alert-danger\" role=\"alert\"><strong>il faut remplir au moin un champ !!</strong>');
} else {
const comentaire = response.data.comentaire;
const nom = response.data.nom;
const prenom = response.data.prenom;
\$('#comentaires').append(\"<h4>\" + nom + \" \" + prenom + \"</h4>\");
if (\$error != \"empty\") {
\$('#comentaires').append(\"<p>\" + comentaire + \"</h>\");
\$('#comentaire').val(\"\");
}
if (newFilename != \"empty\") {
const assetsBaseDir = \"";
        // line 941
        echo twig_escape_filter($this->env, $this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("img/comentaire/"), "html", null, true);
        echo "\";
\$('#comentaires').append('<div class=\"container\"><img style=\"height:200px; width:200px ;\" src=\"' + assetsBaseDir + newFilename + '\"></div>');
}
\$('#comentaires').append('<div id=\"border\" class=\"bordered_1px\"></div>');
\$('#error').hide();
}
}).catch(function (error) {
console.log(error);
});
});
})();
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t";
        
        $__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02->leave($__internal_319393461309892924ff6e74d6d6e64287df64b63545b994e100d4ab223aed02_prof);

        
        $__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e->leave($__internal_085b0142806202599c7fe3b329164a92397d8978207a37e79d70b8c52599e33e_prof);

    }

    public function getTemplateName()
    {
        return "destination_details/index.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  1463 => 941,  1430 => 911,  1425 => 910,  1415 => 909,  1393 => 895,  1383 => 888,  1375 => 882,  1361 => 870,  1359 => 869,  1352 => 865,  1342 => 858,  1328 => 846,  1320 => 843,  1314 => 840,  1311 => 839,  1309 => 838,  1305 => 837,  1301 => 836,  1296 => 835,  1292 => 834,  1280 => 824,  1273 => 819,  1267 => 818,  1261 => 817,  1251 => 811,  1247 => 809,  1243 => 807,  1241 => 806,  1237 => 805,  1230 => 801,  1223 => 797,  1216 => 794,  1213 => 793,  1208 => 792,  1204 => 791,  1192 => 781,  1190 => 780,  1185 => 777,  1178 => 772,  1172 => 771,  1166 => 770,  1154 => 762,  1150 => 760,  1146 => 758,  1144 => 757,  1140 => 756,  1133 => 752,  1126 => 748,  1119 => 745,  1116 => 744,  1111 => 743,  1107 => 742,  1095 => 732,  1093 => 731,  1088 => 728,  1082 => 724,  1076 => 723,  1070 => 722,  1057 => 713,  1053 => 711,  1049 => 709,  1047 => 708,  1043 => 707,  1036 => 703,  1029 => 699,  1022 => 696,  1019 => 695,  1014 => 694,  1010 => 693,  998 => 683,  996 => 682,  991 => 679,  985 => 675,  979 => 674,  973 => 673,  960 => 664,  956 => 662,  952 => 660,  950 => 659,  946 => 658,  939 => 654,  930 => 650,  923 => 647,  920 => 646,  915 => 645,  911 => 644,  898 => 633,  896 => 632,  870 => 609,  850 => 592,  842 => 587,  838 => 586,  794 => 545,  506 => 260,  496 => 253,  485 => 245,  470 => 233,  441 => 207,  437 => 206,  431 => 202,  420 => 197,  415 => 195,  411 => 194,  406 => 191,  402 => 190,  399 => 189,  388 => 184,  383 => 182,  379 => 181,  374 => 178,  370 => 177,  367 => 176,  356 => 171,  351 => 169,  347 => 168,  342 => 165,  338 => 164,  335 => 163,  324 => 158,  319 => 156,  315 => 155,  310 => 152,  306 => 151,  290 => 137,  287 => 127,  280 => 123,  275 => 120,  268 => 116,  263 => 113,  261 => 112,  258 => 111,  251 => 107,  246 => 104,  239 => 100,  234 => 97,  232 => 96,  229 => 95,  222 => 91,  217 => 88,  210 => 84,  205 => 81,  203 => 80,  200 => 79,  193 => 75,  188 => 72,  181 => 68,  176 => 65,  174 => 64,  140 => 33,  125 => 20,  121 => 18,  117 => 16,  115 => 15,  111 => 14,  106 => 12,  100 => 10,  97 => 9,  95 => 8,  90 => 7,  80 => 6,  60 => 3,  37 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'base.html.twig' %}

{% block title %}Hello DestinationDetailsController!
{% endblock %}

{% block body %}
\t{{ app.session.set('ville',ville.name)}}
\t{% set d = app.session.remove('destination') %}
\t{% set c =  app.session.remove('contact') %}
\t<div class=\"destination_banner_wrap overlay\" style=\"background-image:url({{asset('/img/place/'~ ville.image)}});\">
\t\t<div class=\"destination_text text-center\">
\t\t\t<h3>{{ville.name | replace({'_': \" \"})}}</h3>
\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t<a href=\"{{path('ville_like', {'id':ville.id})}}\" class=\"btn btn-link js-like\">
\t\t\t\t\t{% if app.user  and  ville.isLikedByUser(app.user) %}
\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x \" style=\" color: red;\"></i>
\t\t\t\t\t{% else %}
\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\" style=\" color: red;\"></i>
\t\t\t\t\t{% endif %}

\t\t\t\t</a>
\t\t\t</span>
\t\t</div>
\t</div>
\t<!-- start description-->
\t<div class=\"destination_details_info\">
\t\t<div class=\"container\">
\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t<div class=\"col-lg-8 col-md-9\">
\t\t\t\t\t<div class=\"destination_info\">

\t\t\t\t\t\t<h3>Description</h3>
\t\t\t\t\t\t{{ville.description | raw}}
\t\t\t\t\t</div>
\t\t\t\t\t<div class=\"bordered_1px\"></div>
\t\t\t\t</div>
\t\t\t</div>
\t\t</div>
\t</div>
\t<!-- end description-->

\t<div class=\"row justify-content-center\">
\t\t<div class=\"col-lg-6\">
\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t<h3>La carte</h3>
\t\t\t</div>
\t\t</div>
\t</div>


\t<!-- start map-->
\t<div class=\"container\">
\t\t<div class=\"d-none d-sm-block mb-5 pb-4\">
\t\t\t<div id=\"map\" style=\"height: 480px; width: 770px; position: relative;\"></div>


\t\t\t<div class=\"col-lg-4\" style=\" left: 790px; top: -480px;\">
\t\t\t\t<div class=\"filter_result_wrap\">
\t\t\t\t\t<h3>Filter de résultats</h3>
\t\t\t\t\t<div class=\"filter_bordered\">
\t\t\t\t\t\t<div class=\"filter_inner\">
\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t<form class=\"was-validated\">
\t\t\t\t\t\t\t\t\t{% if hotelMarkers is not empty %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/hotel_30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control form-check-inline custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation1\" value=\"hotels\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation1\">Hotels</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/hotel_30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if restoMarkers is not empty %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/resto_30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation2\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation2\">Restorants</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/resto_30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if activiteMarkers is not empty %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/activite30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation3\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation3\">Activités</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/activite30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}

\t\t\t\t\t\t\t\t\t{% if campingMarkers is not empty %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required checked>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/tent30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t<div class=\"custom-control custom-checkbox mb-3\">
\t\t\t\t\t\t\t\t\t\t\t<input type=\"checkbox\" class=\"custom-control-input\" id=\"customControlValidation4\" value=\"restos\" required disabled>
\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-control-label\" for=\"customControlValidation4\">Campings</label>
\t\t\t\t\t\t\t\t\t\t\t<img src='{{asset(\"img/marker_icon/tent30.png\")}}' alt=\"\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"invalid-feedback\">Not checked</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t{# <div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t                                        
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div> #}
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t</div>
\t\t\t</div>
\t\t\t<script language=\"JavaScript\" type=\"text/javascript\" src=\"/js/vendor/jquery-1.12.4.min.js\"></script>


\t\t\t<script>
\t\t\t\tvar hotelMarkers = [];
var campingMarkers = [];
var restoMarkers = [];
var activiteMarkers = [];
\t\t\t</script>
\t\t\t{% for hotelMarker in hotelMarkers %}
\t\t\t\t<script>
\t\t\t\t\tvar hotelMarker = {
position: {
lat: {{ hotelMarker.lat }},
lng: {{ hotelMarker.lng }}
},
title: \"{{ hotelMarker.name | replace({' ': '_'}) }}\"
};
hotelMarkers.push(hotelMarker);
\t\t\t\t</script>
\t\t\t\t{% endfor%}

\t\t\t\t{% for campingMarker in campingMarkers %}
\t\t\t\t\t<script>
\t\t\t\t\t\tvar campingMarker = {
position: {
lat: {{ campingMarker.lat }},
lng: {{ campingMarker.lng }}
},
title: \"{{ campingMarker.name | replace({' ': '_'}) }}\"
};
campingMarkers.push(campingMarker);
\t\t\t\t\t</script>
\t\t\t\t\t{% endfor%}

\t\t\t\t\t{% for activiteMarker in activiteMarkers %}
\t\t\t\t\t\t<script>
\t\t\t\t\t\t\tvar activiteMarker = {
position: {
lat: {{ activiteMarker.lat }},
lng: {{ activiteMarker.lng }}
},
title: \"{{ activiteMarker.name | replace({' ': '_'}) }}\"
};
activiteMarkers.push(activiteMarker);
\t\t\t\t\t\t</script>
\t\t\t\t\t\t{% endfor%}

\t\t\t\t\t\t{% for restoMarker in restoMarkers %}
\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tvar restoMarker = {
position: {
lat: {{ restoMarker.lat }},
lng: {{ restoMarker.lng }}
},
title: \"{{ restoMarker.name | replace({' ': '_'}) }}\"
};
restoMarkers.push(restoMarker);
\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t{% endfor%}

\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\tfunction initMap() {
var uluru = {
lat: {{ villeMarker.lat }},
lng: {{ villeMarker.lng }}
};

var map = new google.maps.Map(document.getElementById('map'), {
zoom: 13,
center: uluru,
scrollwheel: true, /*mapTypeId: 'satellite'*/
mapTypeId: google.maps.MapTypeId.ROADMAP
});
var marker = new google.maps.Marker({
position: uluru, map: map, clickable: true, animation: google.maps.Animation.BOUNCE /*DROP*/
});
marker.setTitle(\"cmnt\");
marker.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + marker.getTitle()).offset().top
}, 'slow');
});

var markers = [];

for (let i = 0; i < hotelMarkers.length; i++) {
var mh = new google.maps.Marker({
position: hotelMarkers[i].position, map: map,
// label: \"H\",
icon: {
url: '{{ asset(\"img/marker_icon/hotel_50.png\") }}'
}
});
mh.setTitle(hotelMarkers[i].title);

markers.push(mh);
}

for (let i = 0; i < restoMarkers.length; i++) {
var mr = new google.maps.Marker({
position: restoMarkers[i].position, map: map,
// label: \"R\"
icon: '{{ asset(\"img/marker_icon/resto_50.png\") }}'
});
mr.setTitle(restoMarkers[i].title);

markers.push(mr);
}

for (let i = 0; i < campingMarkers.length; i++) {
var mc = new google.maps.Marker({position: campingMarkers[i].position, map: map, icon: '{{ asset(\"img/marker_icon/tent50.png\") }}'});
mc.setTitle(campingMarkers[i].title);

markers.push(mc);
}

for (let i = 0; i < activiteMarkers.length; i++) {
var ma = new google.maps.Marker({position: activiteMarkers[i].position, map: map, icon: '{{ asset(\"img/marker_icon/activite50.png\") }}'});
ma.setTitle(activiteMarkers[i].title);

markers.push(ma);
}

var infowindow = new google.maps.InfoWindow();
markers.map((m) => {
m.addListener('click', function () {
\$('html,body').animate({
scrollTop: \$(\"#\" + m.getTitle()).offset().top
}, 'slow');
\$(\"#\" + m.getTitle()).hide(1100);
\$(\"#\" + m.getTitle()).show(2000);
// \$(\"#\" + m.getTitle()).animate({height: '+=20%'});


});

m.addListener('mouseover', function () {
infowindow.setContent(m.getTitle());
infowindow.open(map, m);
});
});

\$(\"#customControlValidation1\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < hotelMarkers.length; i++) {
if (m.getTitle() == hotelMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation3\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < activiteMarkers.length; i++) {
if (m.getTitle() == activiteMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation2\").change(function () {

if (this.checked) {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < restoMarkers.length; i++) {
if (m.getTitle() == restoMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

\$(\"#customControlValidation4\").change(function () {
if (this.checked) {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(true);
}
}
});
} else {
markers.map((m) => {
for (let i = 0; i < campingMarkers.length; i++) {
if (m.getTitle() == campingMarkers[i].title) {
m.setVisible(false);
}
}
});
}
});

}
\t\t\t\t\t\t\t</script>

\t\t\t\t\t\t\t<script async defer src=\"https://maps.googleapis.com/maps/api/js?key=AIzaSyCmC9pqdr3_Wbb9jGSl9EBKNNNAhcA6puE&callback=initMap\"></script>

\t\t\t\t\t\t</div>
\t\t\t\t\t</div>

\t\t\t\t\t<!-- end description-->

\t\t\t\t\t<!-- Start meteo -->
\t\t\t\t\t<style type=\"text/css\">
\t\t\t\t\t\t@import url(https://fonts.googleapis.com/css?family=Roboto:400,300);
\t\t\t\t\t\t{
\t\t\t\t\t\t\t# html,
\t\t\t\t\t\t\tbody {
\t\t\t\t\t\t\t\tbackground-color: #F3F3F3;
\t\t\t\t\t\t\t\tfont-family: 'Roboto', sans-serif;
\t\t\t\t\t\t\t} #
\t\t\t\t\t\t}

\t\t\t\t\t\t.card {
\t\t\t\t\t\t\tmargin: 5% auto 0;
\t\t\t\t\t\t\tpadding: 5px 30px;
\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\tborder-radius: 3px;
\t\t\t\t\t\t\tbackground-color: #fff;
\t\t\t\t\t\t\tbox-shadow: 1px 2px 10px rgba(0, 0, 0, 0.2);
\t\t\t\t\t\t\t-webkit-animation: open 2s cubic-bezier(0.39, 0, 0.38, 1);
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes open {
\t\t\t\t\t\t\tfrom {
\t\t\t\t\t\t\t\tpadding: 0 30px;
\t\t\t\t\t\t\t\theight: 0;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\tto {
\t\t\t\t\t\t\t\theight: 470px;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}

\t\t\t\t\t\th1,
\t\t\t\t\t\th2,
\t\t\t\t\t\th3,
\t\t\t\t\t\th4 {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t}

\t\t\t\t\t\t.dot {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sky {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\tmargin-top: 108px;
\t\t\t\t\t\t\twidth: 100px;
\t\t\t\t\t\t\theight: 100px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #03A9F4;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.sun {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: -3px;
\t\t\t\t\t\t\twidth: 55px;
\t\t\t\t\t\t\theight: 55px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground-color: #FFEB3B;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.5s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: 60px;
\t\t\t\t\t\t\tleft: 30px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before,
\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\tdisplay: block;
\t\t\t\t\t\t\tcontent: \"\";
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:before {
\t\t\t\t\t\t\tmargin-left: -10px;
\t\t\t\t\t\t\twidth: 51px;
\t\t\t\t\t\t\theight: 18px;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\t.cloud:after {
\t\t\t\t\t\t\tposition: absolute;
\t\t\t\t\t\t\ttop: -10px;
\t\t\t\t\t\t\tleft: -22px;
\t\t\t\t\t\t\twidth: 28px;
\t\t\t\t\t\t\theight: 28px;
\t\t\t\t\t\t\tborder-radius: 50%;
\t\t\t\t\t\t\tbackground: #fff;
\t\t\t\t\t\t\tbox-shadow: 50px -6px 0 6px #fff, 25px -19px 0 10px #fff;
\t\t\t\t\t\t}

\t\t\t\t\t\ttable {
\t\t\t\t\t\t\tposition: relative;
\t\t\t\t\t\t\ttop: 10px;
\t\t\t\t\t\t\twidth: 100%;
\t\t\t\t\t\t\ttext-align: center;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(1) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(1) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 32px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.7s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(2) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) td:nth-child(1),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(3),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(4),
\t\t\t\t\t\ttr:nth-child(3) td:nth-child(5) {
\t\t\t\t\t\t\tpadding-bottom: 7px;
\t\t\t\t\t\t\t-webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.9s;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(2),
\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tfont-size: 0.9em;
\t\t\t\t\t\t}

\t\t\t\t\t\ttr:nth-child(3) {
\t\t\t\t\t\t\tcolor: #999;
\t\t\t\t\t\t}

\t\t\t\t\t\t@-webkit-keyframes up {
\t\t\t\t\t\t\t0% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t50% {
\t\t\t\t\t\t\t\topacity: 0;
\t\t\t\t\t\t\t\t-webkit-transform: translateY(15px);
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t99% {
\t\t\t\t\t\t\t\t-webkit-animation-play-state: paused;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t\t100% {
\t\t\t\t\t\t\t\topacity: 1;
\t\t\t\t\t\t\t}
\t\t\t\t\t\t}
\t\t\t\t\t</style>
\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t<h3>La Meteo</h3>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t<div class=\"col-lg-5\">
\t\t\t\t\t\t\t\t\t<div class=\"card\">

\t\t\t\t\t\t\t\t\t\t<h2 style=\"font-weight: 300; font-size: 2.25em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1); \">{{ville.name}}</h2>
\t\t\t\t\t\t\t\t\t\t<h3 id=\"day0\" style=\"float: right; left: 260px; top: -47px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\"></h3>
\t\t\t\t\t\t\t\t\t\t<h3 style=\"float: left; margin-right: 33px; top: 0px; color: #777; font-weight: 400; font-size: 1em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.1s;\" id=\"desc\"></h3>
\t\t\t\t\t\t\t\t\t\t<h1 id=\"temp\" style=\"float: right; color: #666; font-weight: 300; top: 32px; font-size: 6.59375em; line-height: 0.2em; -webkit-animation: up 2s cubic-bezier(0.39, 0, 0.38, 1) 0.2s;\">&deg;</h1>
\t\t\t\t\t\t\t\t\t\t<div id=\"sky\"></div>
\t\t\t\t\t\t\t\t\t\t<table>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"day5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"icond5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMaxd5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t\t<tr>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind1\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind2\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind3\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind4\"></td>
\t\t\t\t\t\t\t\t\t\t\t\t<td id=\"tempMind5\"></td>
\t\t\t\t\t\t\t\t\t\t\t</tr>
\t\t\t\t\t\t\t\t\t\t</table>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t</div>
\t\t\t\t\t<script>
\t\t\t\t\t\tvar lat = {{ villeMarker.lat }};
var lng = {{ villeMarker.lng }};

fetch('https://api.openweathermap.org/data/2.5/onecall?lat=' + lat + '&lon=' + lng + '&units=metric&appid=7215d0713dbd93f757a51b198da702cc').then(response => response.json()).then(data => {
console.log(data);
document.getElementById(\"temp\").innerHTML = data.current.temp + '&deg;';
document.getElementById(\"sky\").innerHTML = '<img src=' + '{{ asset(\"img/weather/\") }}' + data.daily[0].weather[0].icon + '.png' + '>';

document.getElementById(\"desc\").innerHTML = data.current.weather[0].description + '<span  id=\"wind\" style=\"margin-left: 24px; color: #999; font-weight: 300;\">Vent ' + data.current.wind_speed + 'm/s <span style=\"margin-left: 0;\" class=\"dot\">•</span> humidité ' + data.current.humidity + '%</span>';

var date0 = new Date();
let dateLocale0 = date0.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});

document.getElementById(\"day0\").innerHTML = dateLocale0;

for (var i = 1; i < 6; i++) {
document.getElementById(\"tempMaxd\" + i).innerHTML = data.daily[i].temp.max + '&deg;';

document.getElementById(\"icond\" + i).innerHTML = '<img style=\"width: 65px\" src=' +'{{ asset(\"img/weather/\") }}' + data.daily[i].weather[0].icon + '.png' + '>';

document.getElementById(\"tempMind\" + i).innerHTML = data.daily[i].temp.min + '&deg;';


var date = new Date();
date.setDate(new Date().getDate() + i);
let dateLocale = date.toLocaleString('fr-FR', {
weekday: 'long',
year: 'numeric',
month: 'long',
day: 'numeric'
});
document.getElementById(\"day\" + i).innerHTML = dateLocale.substr(0, 3).toUpperCase();

}

});
\t\t\t\t\t</script>

\t\t\t\t\t<!-- End meteo -->


\t\t\t\t\t{% if hotels is not empty  and hotelMarkers is not empty %}
\t\t\t\t\t\t<!-- start hotels-->
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Hotels</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t{% for marker in hotelMarkers %}
\t\t\t\t\t\t\t\t\t\t{% for hotel in  hotels%}
\t\t\t\t\t\t\t\t\t\t\t{% if marker.name | replace({' ': '_'}) == hotel.nom | replace({' ': '_'}) %}
\t\t\t\t\t\t\t\t\t\t\t\t<div id={{marker.name | replace({' ': '_'} )}} class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img src=\"{{asset('/img/hotel/' ~ hotel.imgPath)}}\" alt={{hotel.nom}}>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>{{marker.name}}</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{path('hotel_like', {'id':hotel.id})}}\" class=\"btn btn-link js-like-hotel\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% if app.user  and  hotel.isLikedByUser(app.user) %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-hotel\">{{hotel.likes| length}}</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}
\t\t\t\t\t<!-- end hotels-->

\t\t\t\t\t<!-- start Restaurants-->
\t\t\t\t\t{% if restos is not empty %}
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Restaurants</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t{% for marker in restoMarkers %}
\t\t\t\t\t\t\t\t\t\t{% for resto in  restos%}
\t\t\t\t\t\t\t\t\t\t\t{% if marker.name | replace({' ': '_'}) == resto.nom | replace({' ': '_'}) %}
\t\t\t\t\t\t\t\t\t\t\t\t<div id={{marker.name| replace({' ': '_'} )}} class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"{{asset('/img/resto/' ~ resto.imgPath)}}\" alt=\"resto.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>{{marker.name}}</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{path('resto_like', {'id':resto.id})}}\" class=\"btn btn-link js-like-resto\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% if app.user  and  resto.isLikedByUser(app.user) %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-resto\">{{resto.likes| length}}</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>
\t\t\t\t\t{% endif %}
\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start activite-->
\t\t\t\t\t{% if activites is not empty %}
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Activités</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t{% for marker in activiteMarkers %}
\t\t\t\t\t\t\t\t\t\t{% for activite in  activites %}
\t\t\t\t\t\t\t\t\t\t\t{% if marker.name | replace({' ': '_'}) == activite.nom | replace({' ': '_'}) %}
\t\t\t\t\t\t\t\t\t\t\t\t<div id={{marker.name| replace({' ': '_'} )}} class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"{{asset('/img/activite/' ~ activite.imgPath)}}\" alt=\"activite.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>{{marker.name}}</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{path('activite_like', {'id':activite.id})}}\" class=\"btn btn-link js-like-activite\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% if app.user  and  activite.isLikedByUser(app.user) %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-activite\">{{activite.likes| length}}</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span></div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t</div>

\t\t\t\t\t{% endif %}
\t\t\t\t\t<!-- end Restaurants-->

\t\t\t\t\t<!-- start campings-->
\t\t\t\t\t{% if campings is not empty %}
\t\t\t\t\t\t<div class=\"popular_places_area\">
\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t<div class=\"col-lg-6\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Campings</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<div class=\"row\">
\t\t\t\t\t\t\t\t\t{% for marker in campingMarkers %}
\t\t\t\t\t\t\t\t\t\t{% for camping in  campings %}
\t\t\t\t\t\t\t\t\t\t\t{% if marker.name | replace({' ': '_'}) == camping.nom | replace({' ': '_'}) %}
\t\t\t\t\t\t\t\t\t\t\t\t<div id={{marker.name| replace({' ': '_'} )}} class=\"col-lg-4 col-md-6\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_place\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"thumb\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"width: 400px; height: 425px;\" src=\"{{asset('/img/camping/' ~ camping.imgPath)}}\" alt=\"camping.nom\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"place_info\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"destination_details.html\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h3>{{marker.name}}</h3>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"rating_days d-flex justify-content-between\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"d-flex justify-content-center align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{path('camping_like', {'id':camping.id})}}\" class=\"btn btn-link js-like-camping\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% if app.user  and  camping.isLikedByUser(app.user) %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"fas fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% else %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<i class=\"far fa-heart fa-7x\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-liks-camping\">{{camping.likes| length}}</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<span class=\"js-label\">J'aime</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</span>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t<!-- end campoings-->
\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t<!-- start comntaire-->

\t\t\t\t\t\t\t\t<div id=\"cmnt\" class=\"destination_details_info \">
\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t<div class=\"section_title text-center mb_70\">
\t\t\t\t\t\t\t\t\t\t\t<h3>Comentaires</h3>
\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t<div class=\"row justify-content-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-8 col-md-9 col-lg-12 \">
\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"destination_info\" id=\"comentaires\">
\t\t\t\t\t\t\t\t\t\t\t\t\t{% for comentaire in comentaires %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<h4>{{comentaire.user.nom }}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t{{comentaire.user.prenom }}</h4>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>{{comentaire.comentaire}}</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% if comentaire.image is not  null %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"container\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<img style=\"height:200px; width:200px ;\" src=\"{{asset('img/comentaire/' ~ comentaire.image)}}\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div id=\"border\" class=\"bordered_1px\"></div>

\t\t\t\t\t\t\t\t\t\t\t\t\t{% endfor %}
\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t<div id=\"Ali\" class=\"bordered_1px\"></div>
\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t<div class=\"newletter_area overlay\">
\t\t\t\t\t\t\t\t\t<div class=\"container  d-flex justify-content-center\">
\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t<div class=\"row align-items-center\">
\t\t\t\t\t\t\t\t\t\t\t\t<form class=\"AjaxForm\" action=\"{{path('comentaire')}}\" method=\"post\" enctype=\"multipart/form-data\">
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"single_input\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<textarea name=\"\" id=\"comentaire\" cols=\"30\" rows=\"7\" placeholder=\" votre comentaire\"></textarea>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input name=\"ville\" id=\"ville\" type=\"hidden\" value=\"{{ville.id}}\">
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"col-lg-12\">

\t\t\t\t\t\t\t\t\t\t\t\t\t\t{%  if app.user %}
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"custom-file\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<input type=\"file\" class=\"custom-file-input\" id=\"customFile\" accept=\"image/png, image/jpeg\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<label class=\"custom-file-label\" for=\"customFile\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tla  photo choisi</label>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br><br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_btn\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button class=\"boxed-btn4 \" type=\"submit\">Envoyer<i class=\"fa fa-send fa-tw cont-send\"></i>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% else %}

\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<div class=\"newsletter_text\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<p>Pour faire un commentaire,  vous devez
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<br>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\têtre connecté ,
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<button type=\"button\" class=\"btn btn-secondary\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t<a href=\"{{path('comentaire')}}\">
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tici</a>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</button>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</p>
\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t\t\t\t\t{% endif %}
\t\t\t\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t\t\t\t</form>
\t\t\t\t\t\t\t\t\t\t\t</div>

\t\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t</div>
\t\t\t\t\t\t\t\t<br><br><br>


\t\t\t\t\t\t\t\t<!-- end comntaire-->

\t\t\t\t\t\t\t{% endblock %}

\t\t\t\t\t\t\t{% block javascripts %}
\t\t\t\t\t\t\t   <script src=\"{{asset('js/like_hotel_camping_activite_resto_ajax.js')}}\"></script>
\t\t\t\t\t\t\t\t<script src=\"{{asset('js/commentaire-ajax.js')}}\"></script>
\t\t\t\t\t\t\t\t<script>
\t\t\t\t\t\t\t\t\t(function () {
document.querySelector('.AjaxForm').addEventListener('submit', function (e) {
e.preventDefault();
var formD = new FormData()
formD.append('comentaire', \$('#comentaire').val());
formD.append('ville', \$('#ville').val());
formD.append('file', document.getElementById('customFile').files[0]);
var contentType = {
headers: {
\"content-type\": \"multipart/form-data\"
}
};
axios.post(\$(\".AjaxForm\").attr('action'), formD, contentType).then(function (response) {
const \$error = response.data.error;
const newFilename = response.data.newFilename;
if (\$error == \"empty\" && newFilename == \"empty\") {
\$('#error').hide();
\$('#comentaires').append('<div id=\"error\"class=\"alert alert-danger\" role=\"alert\"><strong>il faut remplir au moin un champ !!</strong>');
} else {
const comentaire = response.data.comentaire;
const nom = response.data.nom;
const prenom = response.data.prenom;
\$('#comentaires').append(\"<h4>\" + nom + \" \" + prenom + \"</h4>\");
if (\$error != \"empty\") {
\$('#comentaires').append(\"<p>\" + comentaire + \"</h>\");
\$('#comentaire').val(\"\");
}
if (newFilename != \"empty\") {
const assetsBaseDir = \"{{ asset('img/comentaire/') }}\";
\$('#comentaires').append('<div class=\"container\"><img style=\"height:200px; width:200px ;\" src=\"' + assetsBaseDir + newFilename + '\"></div>');
}
\$('#comentaires').append('<div id=\"border\" class=\"bordered_1px\"></div>');
\$('#error').hide();
}
}).catch(function (error) {
console.log(error);
});
});
})();
\t\t\t\t\t\t\t\t</script>
\t\t\t\t\t\t\t{% endblock %}
", "destination_details/index.html.twig", "C:\\wamp\\www\\TP\\tourisme-au-maroc\\templates\\destination_details\\index.html.twig");
    }
}
