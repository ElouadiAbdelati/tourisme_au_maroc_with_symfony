<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/_profiler' => [[['_route' => '_profiler_home', '_controller' => 'web_profiler.controller.profiler::homeAction'], null, null, null, true, false, null]],
        '/_profiler/search' => [[['_route' => '_profiler_search', '_controller' => 'web_profiler.controller.profiler::searchAction'], null, null, null, false, false, null]],
        '/_profiler/search_bar' => [[['_route' => '_profiler_search_bar', '_controller' => 'web_profiler.controller.profiler::searchBarAction'], null, null, null, false, false, null]],
        '/_profiler/phpinfo' => [[['_route' => '_profiler_phpinfo', '_controller' => 'web_profiler.controller.profiler::phpinfoAction'], null, null, null, false, false, null]],
        '/_profiler/open' => [[['_route' => '_profiler_open_file', '_controller' => 'web_profiler.controller.profiler::openAction'], null, null, null, false, false, null]],
        '/access/denied' => [[['_route' => 'access_denied_handler', '_controller' => 'App\\Controller\\AccessDeniedHandlerController::index'], null, null, null, false, false, null]],
        '/activite' => [[['_route' => 'activite_index', '_controller' => 'App\\Controller\\ActiviteController::index'], null, ['GET' => 0], null, true, false, null]],
        '/activite/new' => [[['_route' => 'activite_new', '_controller' => 'App\\Controller\\ActiviteController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/camping' => [[['_route' => 'camping_index', '_controller' => 'App\\Controller\\CampingController::index'], null, ['GET' => 0], null, true, false, null]],
        '/camping/new' => [[['_route' => 'camping_new', '_controller' => 'App\\Controller\\CampingController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/contact' => [[['_route' => 'contact', '_controller' => 'App\\Controller\\ContactController::index'], null, null, null, false, false, null]],
        '/email' => [[['_route' => 'send_email', '_controller' => 'App\\Controller\\ContactController::sendEmail'], null, null, null, false, false, null]],
        '/destination' => [[['_route' => 'destination', '_controller' => 'App\\Controller\\DestinationController::index'], null, null, null, false, false, null]],
        '/destination/filter' => [[['_route' => 'destination_filter', '_controller' => 'App\\Controller\\DestinationController::filterDestination'], null, null, null, false, false, null]],
        '/comentaire' => [[['_route' => 'comentaire', '_controller' => 'App\\Controller\\DestinationDetailsController::comentaire'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/accuiel' => [[['_route' => 'home', '_controller' => 'App\\Controller\\HomeController::index'], null, null, null, true, false, null]],
        '/hotel' => [[['_route' => 'hotel_index', '_controller' => 'App\\Controller\\HotelController::index'], null, ['GET' => 0], null, true, false, null]],
        '/hotel/new' => [[['_route' => 'hotel_new', '_controller' => 'App\\Controller\\HotelController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/marker' => [[['_route' => 'marker_index', '_controller' => 'App\\Controller\\MarkerController::index'], null, ['GET' => 0], null, true, false, null]],
        '/marker/new' => [[['_route' => 'marker_new', '_controller' => 'App\\Controller\\MarkerController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/region' => [[['_route' => 'region_index', '_controller' => 'App\\Controller\\RegionController::index'], null, ['GET' => 0], null, true, false, null]],
        '/region/new' => [[['_route' => 'region_new', '_controller' => 'App\\Controller\\RegionController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/register' => [[['_route' => 'app_register', '_controller' => 'App\\Controller\\RegistrationController::register'], null, null, null, false, false, null]],
        '/resto' => [[['_route' => 'resto_index', '_controller' => 'App\\Controller\\RestoController::index'], null, ['GET' => 0], null, true, false, null]],
        '/resto/new' => [[['_route' => 'resto_new', '_controller' => 'App\\Controller\\RestoController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/login' => [[['_route' => 'app_login', '_controller' => 'App\\Controller\\SecurityController::login'], null, null, null, false, false, null]],
        '/logout' => [[['_route' => 'app_logout', '_controller' => 'App\\Controller\\SecurityController::logout'], null, null, null, false, false, null]],
        '/ville' => [[['_route' => 'ville_index', '_controller' => 'App\\Controller\\VilleController::index'], null, ['GET' => 0], null, true, false, null]],
        '/ville/new' => [[['_route' => 'ville_new', '_controller' => 'App\\Controller\\VilleController::new'], null, ['GET' => 0, 'POST' => 1], null, false, false, null]],
        '/admin' => [[['_route' => 'easyadmin', '_controller' => 'EasyCorp\\Bundle\\EasyAdminBundle\\Controller\\EasyAdminController::indexAction'], null, null, null, true, false, null]],
        '/ controller:App\\Controller\\HomeController::index' => [[['_route' => 'index'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_(?'
                    .'|error/(\\d+)(?:\\.([^/]++))?(*:38)'
                    .'|wdt/([^/]++)(*:57)'
                    .'|profiler/([^/]++)(?'
                        .'|/(?'
                            .'|search/results(*:102)'
                            .'|router(*:116)'
                            .'|exception(?'
                                .'|(*:136)'
                                .'|\\.css(*:149)'
                            .')'
                        .')'
                        .'|(*:159)'
                    .')'
                .')'
                .'|/activite/([^/]++)(?'
                    .'|(*:190)'
                    .'|/(?'
                        .'|edit(*:206)'
                        .'|like(*:218)'
                    .')'
                    .'|(*:227)'
                .')'
                .'|/camping/([^/]++)(?'
                    .'|(*:256)'
                    .'|/(?'
                        .'|edit(*:272)'
                        .'|like(*:284)'
                    .')'
                    .'|(*:293)'
                .')'
                .'|/([^/]++)/details(*:319)'
                .'|/hotel/([^/]++)(?'
                    .'|(*:345)'
                    .'|/(?'
                        .'|edit(*:361)'
                        .'|like(*:373)'
                    .')'
                    .'|(*:382)'
                .')'
                .'|/marker/([^/]++)(?'
                    .'|(*:410)'
                    .'|/edit(*:423)'
                    .'|(*:431)'
                .')'
                .'|/re(?'
                    .'|gion/([^/]++)(?'
                        .'|(*:462)'
                        .'|/edit(*:475)'
                        .'|(*:483)'
                    .')'
                    .'|sto/([^/]++)(?'
                        .'|(*:507)'
                        .'|/(?'
                            .'|edit(*:523)'
                            .'|like(*:535)'
                        .')'
                        .'|(*:544)'
                    .')'
                .')'
                .'|/ville/([^/]++)(?'
                    .'|(*:572)'
                    .'|/(?'
                        .'|edit(*:588)'
                        .'|like(*:600)'
                    .')'
                    .'|(*:609)'
                .')'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        38 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        57 => [[['_route' => '_wdt', '_controller' => 'web_profiler.controller.profiler::toolbarAction'], ['token'], null, null, false, true, null]],
        102 => [[['_route' => '_profiler_search_results', '_controller' => 'web_profiler.controller.profiler::searchResultsAction'], ['token'], null, null, false, false, null]],
        116 => [[['_route' => '_profiler_router', '_controller' => 'web_profiler.controller.router::panelAction'], ['token'], null, null, false, false, null]],
        136 => [[['_route' => '_profiler_exception', '_controller' => 'web_profiler.controller.exception_panel::body'], ['token'], null, null, false, false, null]],
        149 => [[['_route' => '_profiler_exception_css', '_controller' => 'web_profiler.controller.exception_panel::stylesheet'], ['token'], null, null, false, false, null]],
        159 => [[['_route' => '_profiler', '_controller' => 'web_profiler.controller.profiler::panelAction'], ['token'], null, null, false, true, null]],
        190 => [[['_route' => 'activite_show', '_controller' => 'App\\Controller\\ActiviteController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        206 => [[['_route' => 'activite_edit', '_controller' => 'App\\Controller\\ActiviteController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        218 => [[['_route' => 'activite_like', '_controller' => 'App\\Controller\\ActiviteController::like'], ['id'], null, null, false, false, null]],
        227 => [[['_route' => 'activite_delete', '_controller' => 'App\\Controller\\ActiviteController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        256 => [[['_route' => 'camping_show', '_controller' => 'App\\Controller\\CampingController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        272 => [[['_route' => 'camping_edit', '_controller' => 'App\\Controller\\CampingController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        284 => [[['_route' => 'camping_like', '_controller' => 'App\\Controller\\CampingController::like'], ['id'], null, null, false, false, null]],
        293 => [[['_route' => 'camping_delete', '_controller' => 'App\\Controller\\CampingController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        319 => [[['_route' => 'destination_details', '_controller' => 'App\\Controller\\DestinationDetailsController::index'], ['name'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        345 => [[['_route' => 'hotel_show', '_controller' => 'App\\Controller\\HotelController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        361 => [[['_route' => 'hotel_edit', '_controller' => 'App\\Controller\\HotelController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        373 => [[['_route' => 'hotel_like', '_controller' => 'App\\Controller\\HotelController::like'], ['id'], null, null, false, false, null]],
        382 => [[['_route' => 'hotel_delete', '_controller' => 'App\\Controller\\HotelController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        410 => [[['_route' => 'marker_show', '_controller' => 'App\\Controller\\MarkerController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        423 => [[['_route' => 'marker_edit', '_controller' => 'App\\Controller\\MarkerController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        431 => [[['_route' => 'marker_delete', '_controller' => 'App\\Controller\\MarkerController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        462 => [[['_route' => 'region_show', '_controller' => 'App\\Controller\\RegionController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        475 => [[['_route' => 'region_edit', '_controller' => 'App\\Controller\\RegionController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        483 => [[['_route' => 'region_delete', '_controller' => 'App\\Controller\\RegionController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        507 => [[['_route' => 'resto_show', '_controller' => 'App\\Controller\\RestoController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        523 => [[['_route' => 'resto_edit', '_controller' => 'App\\Controller\\RestoController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        535 => [[['_route' => 'resto_like', '_controller' => 'App\\Controller\\RestoController::like'], ['id'], null, null, false, false, null]],
        544 => [[['_route' => 'resto_delete', '_controller' => 'App\\Controller\\RestoController::delete'], ['id'], ['DELETE' => 0], null, false, true, null]],
        572 => [[['_route' => 'ville_show', '_controller' => 'App\\Controller\\VilleController::show'], ['id'], ['GET' => 0], null, false, true, null]],
        588 => [[['_route' => 'ville_edit', '_controller' => 'App\\Controller\\VilleController::edit'], ['id'], ['GET' => 0, 'POST' => 1], null, false, false, null]],
        600 => [[['_route' => 'ville_like', '_controller' => 'App\\Controller\\VilleController::like'], ['id'], null, null, false, false, null]],
        609 => [
            [['_route' => 'ville_delete', '_controller' => 'App\\Controller\\VilleController::delete'], ['id'], ['DELETE' => 0], null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
